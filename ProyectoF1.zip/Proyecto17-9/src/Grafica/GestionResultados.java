
package Grafica;

import Logica.Persistenciaa;
import Logica.Auto;
import Logica.Fachada;
import Logica.GranPremio;
import Logica.Piloto;
import Logica.Resultado;
import Logica.Temporada;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 58153596
 */
public class GestionResultados extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionResultados.class.getName());


    public GestionResultados() {
        initComponents();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cargarTemporadas();
        cargarPilotos();
        cargarAutos();
        cargarTabla();
        cargarGrandesPremios();
    }
    private Resultado resultadoSeleccionado;

    public void cargarTemporadas(){
        jComboGR.removeAllItems();
        
        for(Temporada temporada : Fachada.getInstancia().obtenerTemporadas()){
            jComboGR.addItem(String.valueOf(temporada.getAnio()));
        }
    }
    
    public void cargarGrandesPremios() {
        jCombo2GR.removeAllItems();

        if (jComboGR.getSelectedItem() != null) {
            int anio = Integer.parseInt(jComboGR.getSelectedItem().toString());
            Temporada temporada = Fachada.getInstancia().buscarTemporada(anio);

            if (temporada != null && temporada.obtenerGrandesPremios() != null) {
                for (GranPremio gp : temporada.obtenerGrandesPremios()) {
                    jCombo2GR.addItem(gp.getIdentificador() + " - " + gp.getNombre());
                }
            }
        }
    }

    public void cargarPilotos() {
    jCombo3GR.removeAllItems();

    for (Piloto piloto : Fachada.getInstancia().obtenerPilotos()) {
        jCombo3GR.addItem(piloto.getCodigo() + " - " + piloto.getNombre() + " " + piloto.getApellido());
    }
}
    public void cargarAutos() {
    jCombo4GR.removeAllItems();

    for (Auto auto : Fachada.getInstancia().obtenerAutos()) {
        jCombo4GR.addItem(String.valueOf(auto.getIdentificador()));
    }
}
    
    public void cargarTabla() {
        
        DefaultTableModel modelo = (DefaultTableModel) jTableGR.getModel();
        modelo.setRowCount(0);

        if (jComboGR.getSelectedItem() == null) {
            return;
        }

        int anio = Integer.parseInt(jComboGR.getSelectedItem().toString());
        Temporada temporada = Fachada.getInstancia().buscarTemporada(anio);

        if (temporada != null && Fachada.getInstancia().obtenerResultadosTemporada(temporada) != null) {
            for (Resultado resultado : Fachada.getInstancia().obtenerResultadosTemporada(temporada)) {
                if (resultado != null && resultado.obtenerGranPremio() != null && resultado.obtenerPiloto() != null && resultado.obtenerAuto() != null) {
                    modelo.addRow(new Object[]{
                        resultado.obtenerGranPremio().getNombre(),
                        resultado.obtenerPiloto().getNombre() + " " + resultado.obtenerPiloto().getApellido(),
                        resultado.obtenerAuto().getIdentificador(),
                        resultado.getPosicion(),
                        resultado.getVueltasCompletadas(),
                        resultado.getTiempoPorVuelta(),
                        resultado.getPuntos()
                    });
                }
            }
        }
}
    
    
    
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboGR = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jCombo2GR = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jCombo3GR = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jCombo4GR = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jTextGR = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jText2GR = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jText3GR = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jAgregarGR = new javax.swing.JButton();
        jEditarGR = new javax.swing.JButton();
        jEliminarGR = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableGR = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GESTIÓN DE RESULTADOS:");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Temporada:");

        jComboGR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jComboGR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboGRActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Gran Premio:");

        jCombo2GR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Piloto:");

        jCombo3GR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Auto:");

        jCombo4GR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel6.setText("Posición:");

        jTextGR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel7.setText("Vueltas completadas:");

        jText2GR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel8.setText("Tiempo por vuelta:");

        jText3GR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jAgregarGR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jAgregarGR.setText("Aregar");
        jAgregarGR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregarGRActionPerformed(evt);
            }
        });

        jEditarGR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jEditarGR.setText("Editar");
        jEditarGR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEditarGRActionPerformed(evt);
            }
        });

        jEliminarGR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jEliminarGR.setText("Eliminar");
        jEliminarGR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminarGRActionPerformed(evt);
            }
        });

        jTableGR.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jTableGR.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Gran Premio", "Piloto", "Auto", "Posicón", "Vueltas", "Tiempo por vuelta", "Puntos"
            }
        ));
        jTableGR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableGRMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableGR);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel9)
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jComboGR, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCombo2GR, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jCombo3GR, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jCombo4GR, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextGR)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jAgregarGR)
                                        .addComponent(jLabel8)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jText2GR)
                                    .addComponent(jText3GR)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(40, 40, 40)
                                        .addComponent(jEditarGR)
                                        .addGap(76, 76, 76)
                                        .addComponent(jEliminarGR)
                                        .addGap(0, 0, Short.MAX_VALUE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(274, 274, 274)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addComponent(jLabel9))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jComboGR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jCombo2GR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jCombo3GR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jCombo4GR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jTextGR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jText2GR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jText3GR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jAgregarGR)
                            .addComponent(jEditarGR)
                            .addComponent(jEliminarGR))))
                .addGap(54, 54, 54)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboGRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboGRActionPerformed
 cargarGrandesPremios();
        cargarTabla();
    
    }//GEN-LAST:event_jComboGRActionPerformed

    private void jAgregarGRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregarGRActionPerformed
   try {
            if (jComboGR.getSelectedItem() == null ||
                jCombo2GR.getSelectedItem() == null ||
                jCombo3GR.getSelectedItem() == null ||
                jCombo4GR.getSelectedItem() == null) {

                JOptionPane.showMessageDialog(this, "Completá todos los datos.");
                return;
            }

            int posicion = Integer.parseInt(jTextGR.getText());
            int vueltas = Integer.parseInt(jText2GR.getText());
            double tiempo = Double.parseDouble(jText3GR.getText());

            if (posicion <= 0 || vueltas <= 0 || tiempo <= 0) {
                JOptionPane.showMessageDialog(this, "Ingresá valores mayores que cero.");
                return;
            }
            int anio = Integer.parseInt(jComboGR.getSelectedItem().toString());
            Temporada temporada = Fachada.getInstancia().buscarTemporada(anio);

            int idGP = Integer.parseInt(jCombo2GR.getSelectedItem().toString().split(" - ")[0]);

            GranPremio granPremio = null;

            for (GranPremio gp : temporada.obtenerGrandesPremios()) {
                if (gp.getIdentificador() == idGP) {
                    granPremio = gp;
                    break;
                }
            }

            String codigoPiloto = jCombo3GR.getSelectedItem().toString().split(" - ")[0];
            Piloto piloto = Fachada.getInstancia().buscarPiloto(codigoPiloto);

            int idAuto = Integer.parseInt(jCombo4GR.getSelectedItem().toString());
            Auto autoSeleccionado = null;

            for (Auto auto : Fachada.getInstancia().obtenerAutos()) {
                if (auto.getIdentificador() == idAuto) {
                    autoSeleccionado = auto;
                    break;
                }
            }

            if (granPremio == null || piloto == null || autoSeleccionado == null) {
                JOptionPane.showMessageDialog(this, "No se encontraron los datos seleccionados.");
                return;
            }

            Resultado resultado = new Resultado(piloto, autoSeleccionado, granPremio, posicion, vueltas, tiempo, 0);
            resultado.calcularPuntos();

            Fachada.getInstancia().registrarResultado(resultado);
            
            String datosResultado = granPremio.getIdentificador() + ":" + piloto.getCodigo() + ":" + autoSeleccionado.getIdentificador() + ":" + posicion + ":" + vueltas + ":" + tiempo + ":" + resultado.getPuntos();
            try {
                Logica.Persistenciaa.EjecutarSentenciaResultado(datosResultado);
                System.out.println("Resultado enviado a la BD con éxito.");
            } catch (Exception e) {
                System.out.println("Error al guardar Resultado en la BD: " + e.getMessage());
            }
            
            cargarTabla();
            
            jTextGR.setText("");
            jText2GR.setText("");
            jText3GR.setText("");
            
            JOptionPane.showMessageDialog(this, "Resultado agregado correctamente.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Revisá los datos numéricos.");
        }
    
    }//GEN-LAST:event_jAgregarGRActionPerformed

    private void jEliminarGRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminarGRActionPerformed
   
        if (resultadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccioná un resultado de la tabla.");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de eliminar este resultado?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmar == JOptionPane.YES_OPTION) {
            int gpId = resultadoSeleccionado.obtenerGranPremio().getIdentificador();
            String pilotoCod = resultadoSeleccionado.obtenerPiloto().getCodigo();

            resultadoSeleccionado.obtenerGranPremio().eliminarResultado(resultadoSeleccionado);

            // Persistencia de eliminación en la BD
            try {
                String sentenciaEliminar = "ELIMINAR:" + gpId + ":" + pilotoCod;
                Logica.Persistenciaa.EjecutarSentenciaResultado(sentenciaEliminar);
                System.out.println("Resultado eliminado de la BD con éxito.");
            } catch (Exception e) {
                System.out.println("Error al eliminar Resultado en la BD: " + e.getMessage());
            }

            resultadoSeleccionado = null;
            cargarTabla();

            jTextGR.setText("");
            jText2GR.setText("");
            jText3GR.setText("");

            JOptionPane.showMessageDialog(this, "Resultado eliminado correctamente.");
        }
    
        
    }//GEN-LAST:event_jEliminarGRActionPerformed

    private void jTableGRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGRMouseClicked
    int fila = jTableGR.getSelectedRow();

    
    if (fila >= 0) {
    int anio = Integer.parseInt(jComboGR.getSelectedItem().toString());
    Temporada temporada = Fachada.getInstancia().buscarTemporada(anio);

    String nombreGP = jTableGR.getValueAt(fila, 0).toString();
    String nombrePiloto = jTableGR.getValueAt(fila, 1).toString();

    for (Resultado resultado : Fachada.getInstancia().obtenerResultadosTemporada(temporada)) {
        String piloto = resultado.obtenerPiloto().getNombre() + " "
                + resultado.obtenerPiloto().getApellido();

        if (resultado.obtenerGranPremio().getNombre().equals(nombreGP)
                && piloto.equals(nombrePiloto)) {
            resultadoSeleccionado = resultado;

            jTextGR.setText(String.valueOf(resultado.getPosicion()));
            jText2GR.setText(String.valueOf(resultado.getVueltasCompletadas()));
            jText3GR.setText(String.valueOf(resultado.getTiempoPorVuelta()));

            break;
        }
    }
}
    }//GEN-LAST:event_jTableGRMouseClicked

    private void jEditarGRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEditarGRActionPerformed

        if (resultadoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccioná un resultado de la tabla.");
            return;
        }

        try {
            int posicion = Integer.parseInt(jTextGR.getText());
            int vueltas = Integer.parseInt(jText2GR.getText());
            double tiempo = Double.parseDouble(jText3GR.getText());

            if (posicion <= 0 || vueltas <= 0 || tiempo <= 0) {
                JOptionPane.showMessageDialog(this, "Ingresá valores mayores que cero.");
                return;
            }

            resultadoSeleccionado.modificarResultado(posicion, vueltas, tiempo, 0);
            resultadoSeleccionado.calcularPuntos();

            // Envía la modificación a la Base de Datos
            try {
                int gpId = resultadoSeleccionado.obtenerGranPremio().getIdentificador();
                String pilotoCod = resultadoSeleccionado.obtenerPiloto().getCodigo();
                int autoId = resultadoSeleccionado.obtenerAuto().getIdentificador();

                String datosResultado = gpId + ":" + pilotoCod + ":" + autoId + ":" + posicion + ":" + vueltas + ":" + tiempo + ":" + resultadoSeleccionado.getPuntos();
                Logica.Persistenciaa.EjecutarSentenciaResultado(datosResultado);
                System.out.println("Resultado modificado en la BD con éxito.");
            } catch (Exception e) {
                System.out.println("Error al modificar Resultado en la BD: " + e.getMessage());
            }

            cargarTabla();
            resultadoSeleccionado = null;

            jTextGR.setText("");
            jText2GR.setText("");
            jText3GR.setText("");

            JOptionPane.showMessageDialog(this, "Resultado modificado correctamente.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Revisá los datos numéricos.");
        
    
        
}    }//GEN-LAST:event_jEditarGRActionPerformed

  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionResultados().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jAgregarGR;
    private javax.swing.JComboBox<String> jCombo2GR;
    private javax.swing.JComboBox<String> jCombo3GR;
    private javax.swing.JComboBox<String> jCombo4GR;
    private javax.swing.JComboBox<String> jComboGR;
    private javax.swing.JButton jEditarGR;
    private javax.swing.JButton jEliminarGR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableGR;
    private javax.swing.JTextField jText2GR;
    private javax.swing.JTextField jText3GR;
    private javax.swing.JTextField jTextGR;
    // End of variables declaration//GEN-END:variables
}

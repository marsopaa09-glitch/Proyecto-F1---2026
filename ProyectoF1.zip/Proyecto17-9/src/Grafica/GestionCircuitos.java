
package Grafica;

import Logica.Persistenciaa;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author 58153596
 */
public class GestionCircuitos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionCircuitos.class.getName());

   
    public GestionCircuitos() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        cargarTabla();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextGC = new javax.swing.JTextField();
        jText2GC = new javax.swing.JTextField();
        jText4GC = new javax.swing.JTextField();
        jText5GC = new javax.swing.JTextField();
        jButtonGC = new javax.swing.JButton();
        jButton2GC = new javax.swing.JButton();
        jButton3GC = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableGC = new javax.swing.JTable();
        jComboGC = new javax.swing.JComboBox<>();

        jLabel7.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GESTIÓN DE CIRCUITOS");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Identificador:");

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Pais:");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Longuitud:");

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel6.setText("Cantidad de vueltas:");

        jTextGC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jText2GC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jText4GC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jText5GC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jButtonGC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButtonGC.setText("Agregar");
        jButtonGC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGCActionPerformed(evt);
            }
        });

        jButton2GC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton2GC.setText("Editar");
        jButton2GC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2GCActionPerformed(evt);
            }
        });

        jButton3GC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton3GC.setText("Eliminar");
        jButton3GC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3GCActionPerformed(evt);
            }
        });

        jTableGC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Identificador", "Nombre", "Pais", "Longuitud", "Cantidad de vueltas"
            }
        ));
        jTableGC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableGCMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableGC);

        jComboGC.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jComboGC.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alemania", "Austria", "Canadá", "Estados Unidos", "Francia", "India", "Irlanda", "Italia", "Japón", "Países Bajos", "Reino Unido", "Rusia", "Sudáfrica", "Suiza", "Uruguay" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 566, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel5))
                                        .addGap(60, 60, 60))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextGC)
                                    .addComponent(jText2GC)
                                    .addComponent(jText4GC)
                                    .addComponent(jText5GC)
                                    .addComponent(jComboGC, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(jButtonGC)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2GC)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                        .addComponent(jButton3GC)
                        .addGap(93, 93, 93)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextGC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jText2GC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboGC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jText4GC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jText5GC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGC)
                    .addComponent(jButton2GC)
                    .addComponent(jButton3GC))
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGCActionPerformed

    try {
        int identificador = Integer.parseInt(jTextGC.getText());
        String nombre = jText2GC.getText();
        String pais = jComboGC.getSelectedItem().toString();
        double longitud = Double.parseDouble(jText4GC.getText());
        int vueltas = Integer.parseInt(jText5GC.getText());

        if (nombre.isEmpty() || pais.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Completá todos los campos.");
            return;
        }

        for (Logica.Circuito c : Logica.Fachada.getInstancia().obtenerCircuitos()) {

            if (c.getIdentificador() == identificador) { javax.swing.JOptionPane.showMessageDialog(this, "Ese identificador ya existe.");
                return;
            }
        }

        Logica.Circuito circuito = new Logica.Circuito(identificador, nombre, pais, longitud, vueltas);

        Logica.Fachada.getInstancia().agregarCircuito(circuito);
        
        String datosCircuito = identificador + ":" + nombre + ":" + pais + ":" + longitud + ":" + vueltas;
        try {
            Logica.Persistenciaa.EjecutarSentenciaCircuito(datosCircuito);
            System.out.println("Circuito enviado a la BD con exito.");
        } catch (Exception e) {
            System.out.println("Error al guardar Circuito en la BD: " + e.getMessage());
        }

        cargarTabla();

        jTextGC.setText("");
        jText2GC.setText("");
        jComboGC.setSelectedIndex(0);
        jText4GC.setText("");
        jText5GC.setText("");

        javax.swing.JOptionPane.showMessageDialog(this, "Circuito agregado correctamente.");

    } catch (NumberFormatException e) {javax.swing.JOptionPane.showMessageDialog(this, "El identificador, la longitud y las vueltas deben ser números.");
    }
    }//GEN-LAST:event_jButtonGCActionPerformed

    private void jButton2GCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2GCActionPerformed

    int fila = jTableGC.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un circuito de la tabla.");
            return;
        }

        try {
            int identificadorAnterior = Integer.parseInt(jTableGC.getValueAt(fila, 0).toString());
            int identificadorNuevo = Integer.parseInt(jTextGC.getText());
            String nombre = jText2GC.getText();

            if (jComboGC.getSelectedItem() == null) {
                javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un país.");
                return;
            }

            String pais = jComboGC.getSelectedItem().toString();
            double longitud = Double.parseDouble(jText4GC.getText());
            int vueltas = Integer.parseInt(jText5GC.getText());

            if (nombre.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Completá todos los campos.");
                return;
            }

            if (longitud <= 0 || vueltas <= 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "La longitud y las vueltas deben ser mayores que cero.");
                return;
            }

            for (Logica.Circuito c : Logica.Fachada.getInstancia().obtenerCircuitos()) {
                if (c.getIdentificador() == identificadorNuevo && identificadorNuevo != identificadorAnterior) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Ese identificador ya está utilizado.");
                    return;
                }
            }

            Logica.Circuito circuito = new Logica.Circuito(identificadorNuevo, nombre, pais, longitud, vueltas);
            Logica.Fachada.getInstancia().modificarCircuito(identificadorAnterior, circuito);

            // Sincronización con la Base de Datos (Actualizar)
            String datosCircuito = identificadorNuevo + ":" + nombre + ":" + pais + ":" + longitud + ":" + vueltas;
            try {
                Logica.Persistenciaa.EjecutarSentenciaCircuito(datosCircuito);
                System.out.println("Circuito actualizado en la BD con éxito.");
            } catch (Exception e) {
                System.out.println("Error al actualizar Circuito en la BD: " + e.getMessage());
            }

            cargarTabla();

            javax.swing.JOptionPane.showMessageDialog(this, "Circuito modificado correctamente.");

        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Revisá los campos numéricos.");
        }
    
    }//GEN-LAST:event_jButton2GCActionPerformed

    private void jButton3GCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3GCActionPerformed

        int fila = jTableGC.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un circuito de la tabla.");
            return;
        }

        int confirmacion = javax.swing.JOptionPane.showConfirmDialog(this,
                "¿Estás seguro de que querés eliminar este circuito?",
                "Confirmar eliminación",
                javax.swing.JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        int identificador = Integer.parseInt(jTableGC.getValueAt(fila, 0).toString());

        Logica.Circuito circuito = new Logica.Circuito(identificador, "", "", 0, 0);
        Logica.Fachada.getInstancia().eliminarCircuito(circuito);

        // Sincronización con la Base de Datos (Eliminar)
        try {
            String sentenciaEliminar = "ELIMINAR:" + identificador;
            Logica.Persistenciaa.EjecutarSentenciaCircuito(sentenciaEliminar);
            System.out.println("Circuito eliminado de la BD con éxito.");
        } catch (Exception e) {
            System.out.println("Error al eliminar Circuito en la BD: " + e.getMessage());
        }

        cargarTabla();
        
        jTextGC.setText("");
        jText2GC.setText("");
        jComboGC.setSelectedIndex(0);
        jText4GC.setText("");
        jText5GC.setText("");
        jTableGC.clearSelection();

        javax.swing.JOptionPane.showMessageDialog(this, "Circuito eliminado correctamente.");
    
        
    }//GEN-LAST:event_jButton3GCActionPerformed

    private void jTableGCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGCMouseClicked
    int fila = jTableGC.getSelectedRow();

    if (fila != -1) {
        jTextGC.setText(jTableGC.getValueAt(fila, 0).toString());
        jText2GC.setText(jTableGC.getValueAt(fila, 1).toString());
        jComboGC.setSelectedItem(jTableGC.getValueAt(fila, 2).toString());
        jText4GC.setText(jTableGC.getValueAt(fila, 3).toString());
        jText5GC.setText(jTableGC.getValueAt(fila, 4).toString());
    }
    }//GEN-LAST:event_jTableGCMouseClicked

    private void cargarTabla(){
        javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) jTableGC.getModel();
        modelo.setRowCount(0);
        
        for(Logica.Circuito circuito : Logica.Fachada.getInstancia().obtenerCircuitos()){
            
            modelo.addRow(new Object[]{
                circuito.getIdentificador(), circuito.getNombre(), circuito.getPais(), circuito.getLongitud(), circuito.getVueltasProgramadas()
            });
        }
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionCircuitos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2GC;
    private javax.swing.JButton jButton3GC;
    private javax.swing.JButton jButtonGC;
    private javax.swing.JComboBox<String> jComboGC;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableGC;
    private javax.swing.JTextField jText2GC;
    private javax.swing.JTextField jText4GC;
    private javax.swing.JTextField jText5GC;
    private javax.swing.JTextField jTextGC;
    // End of variables declaration//GEN-END:variables
}

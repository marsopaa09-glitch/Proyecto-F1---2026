
package Grafica;

import Logica.Persistenciaa;
import Logica.Auto;
import Logica.Escuderia;
import Logica.Fachada;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class GestionAutos extends javax.swing.JFrame {
    
    private Auto autoSeleccionado;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionAutos.class.getName());

    public GestionAutos() {
        initComponents();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        cargarEscuderias();
        cargarTabla();
        
    }
    
    
 public void cargarEscuderias(){
     jComboGA.removeAllItems();
     
     for(Escuderia escuderia : Fachada.getInstancia().obtenerEscuderias()){
         jComboGA.addItem(escuderia.getIdentificador() + "-" + escuderia.getNombre());
     }
 }   
 
 public void cargarTabla() {
    DefaultTableModel modelo = (DefaultTableModel) jTableGA.getModel();
    modelo.setRowCount(0);

    for (Auto auto : Fachada.getInstancia().obtenerAutos()) {
        String nombreEscuderia = "";

        if (auto.obtenerEscuderia() != null) {
            nombreEscuderia = auto.obtenerEscuderia().getNombre();
        }

        modelo.addRow(new Object[]{
            auto.getIdentificador(), auto.getModelo(), auto.getAnioFabricacion(), nombreEscuderia
        });
    }
}
 

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextGA = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jText2GA = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jText3GA = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jComboGA = new javax.swing.JComboBox<>();
        jAgregarGA = new javax.swing.JButton();
        jEditarGA = new javax.swing.JButton();
        jEliminarGA = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableGA = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GESTIÓN AUTOS");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Identificador:");

        jTextGA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Modelo:");

        jText2GA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Año de fabricación:");

        jText3GA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Escudería:");

        jComboGA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jAgregarGA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jAgregarGA.setText("Agregar");
        jAgregarGA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregarGAActionPerformed(evt);
            }
        });

        jEditarGA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jEditarGA.setText("Editar");
        jEditarGA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEditarGAActionPerformed(evt);
            }
        });

        jEliminarGA.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jEliminarGA.setText("Eliminar");
        jEliminarGA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminarGAActionPerformed(evt);
            }
        });

        jTableGA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Identificador", "Modelo", "Año de fabricación", "Escudería"
            }
        ));
        jTableGA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableGAMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableGA);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jAgregarGA)
                                .addGap(90, 90, 90)
                                .addComponent(jEditarGA)
                                .addGap(85, 85, 85)
                                .addComponent(jEliminarGA))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jText3GA))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addGap(35, 35, 35)
                                    .addComponent(jComboGA, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jTextGA)
                                        .addComponent(jText2GA, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextGA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jText2GA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jText3GA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboGA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAgregarGA)
                    .addComponent(jEditarGA)
                    .addComponent(jEliminarGA))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jAgregarGAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregarGAActionPerformed
    try {
    int identificador = Integer.parseInt(jTextGA.getText());
    String modelo = jText2GA.getText();
    String anio = jText3GA.getText();

    if (modelo.isEmpty() || anio.isEmpty() || jComboGA.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(this, "Completá todos los datos.");
        return;
    }

    int anioFabricacion = Integer.parseInt(anio);
    String textoEscuderia = jComboGA.getSelectedItem().toString();

    int posicionGuion = textoEscuderia.indexOf("-");
    String identificadorEscuderia = textoEscuderia.substring(0, posicionGuion);

    int idEscuderia = Integer.parseInt(identificadorEscuderia);
    Escuderia escuderiaSeleccionada = Fachada.getInstancia().buscarEscuderia(idEscuderia);

    if (escuderiaSeleccionada == null) {
        JOptionPane.showMessageDialog(this, "No se encontró la escudería.");
        return;
    }

    Auto auto = new Auto(identificador, modelo, anio);
    auto.asignarEscuderia(escuderiaSeleccionada);

    Fachada.getInstancia().agregarAuto(auto);
    
    String datosAuto = identificador + ":" + modelo + ":" + anioFabricacion + ":" + escuderiaSeleccionada.getIdentificador();
    try {
        Logica.Persistenciaa.EjecutarSentenciaAuto(datosAuto);
        System.out.println("Auto enviado a la BD con éxito.");
    } catch (Exception e) {
        System.out.println("Error al guardar Auto en la BD: " + e.getMessage());
    }

    cargarTabla();

    JOptionPane.showMessageDialog(this, "Auto agregado correctamente.");

    } catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(this, "Error al convertir un número:" + e.getMessage());
    }
    }//GEN-LAST:event_jAgregarGAActionPerformed

    private void jTableGAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGAMouseClicked
    int fila = jTableGA.getSelectedRow();

    if (fila >= 0) {
    int identificador = Integer.parseInt(jTableGA.getValueAt(fila, 0).toString());

    for (Auto auto : Fachada.getInstancia().obtenerAutos()) {
        if (auto.getIdentificador() == identificador) {
            autoSeleccionado = auto;

            jTextGA.setText(String.valueOf(auto.getIdentificador()));
            jText2GA.setText(auto.getModelo());
            jText3GA.setText(auto.getAnioFabricacion());

            if (auto.obtenerEscuderia() != null) {
                String escuderia = auto.obtenerEscuderia().getIdentificador()
                        + " - " + auto.obtenerEscuderia().getNombre();

                jComboGA.setSelectedItem(escuderia);
            }

            break;
        }
    }
    }
    }//GEN-LAST:event_jTableGAMouseClicked

    private void jEditarGAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEditarGAActionPerformed
        if (autoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccioná un auto de la tabla.");
            return;
        }

        try {
            int identificador = Integer.parseInt(jTextGA.getText());
            String modelo = jText2GA.getText();
            String anio = jText3GA.getText();

            if (modelo.isEmpty() || anio.isEmpty() || jComboGA.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Completá todos los datos.");
                return;
            }

            int anioFabricacion = Integer.parseInt(anio);
            String textoEscuderia = jComboGA.getSelectedItem().toString();

            int posicionGuion = textoEscuderia.indexOf("-");
            String identificadorEscuderia = textoEscuderia.substring(0, posicionGuion);

            identificadorEscuderia = identificadorEscuderia.replace(" ", "");
            int idEscuderia = Integer.parseInt(identificadorEscuderia);

            Escuderia escuderia = Fachada.getInstancia().buscarEscuderia(idEscuderia);
            if (escuderia == null) {
                JOptionPane.showMessageDialog(this, "No se encontró la escudería.");
                return;
            }

            // Sincronización con la Base de Datos (Actualizar)
            String datosAuto = identificador + ":" + modelo + ":" + anioFabricacion + ":" + escuderia.getIdentificador();
            try {
                Persistenciaa.EjecutarSentenciaAuto(datosAuto);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al actualizar en la Base de Datos: " + e.getMessage());
                return;
            }

            Auto auto = new Auto(identificador, modelo, anio);
            auto.asignarEscuderia(escuderia);

            Fachada.getInstancia().modificarAuto(auto);

            autoSeleccionado = null;
            cargarTabla();

            JOptionPane.showMessageDialog(this, "Auto modificado correctamente.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El identificador y el año deben ser números.");
        }
    
    
    
    }//GEN-LAST:event_jEditarGAActionPerformed

    private void jEliminarGAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminarGAActionPerformed
        if (autoSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccioná un auto de la tabla.");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de eliminar este auto?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmar == JOptionPane.YES_OPTION) {
            // Sincronización con la Base de Datos (Eliminar)
            try {
                String sentenciaEliminar = "ELIMINAR:" + autoSeleccionado.getIdentificador();
                Persistenciaa.EjecutarSentenciaAuto(sentenciaEliminar);
            } catch (Exception e) {
                System.out.println("Error al eliminar en BD: " + e.getMessage());
            }

            Fachada.getInstancia().eliminarAuto(autoSeleccionado);

            autoSeleccionado = null;

            cargarTabla();

            jTextGA.setText("");
            jText2GA.setText("");
            jText3GA.setText("");

            JOptionPane.showMessageDialog(this, "Auto eliminado correctamente.");
        }
    
    }//GEN-LAST:event_jEliminarGAActionPerformed

  
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionAutos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jAgregarGA;
    private javax.swing.JComboBox<String> jComboGA;
    private javax.swing.JButton jEditarGA;
    private javax.swing.JButton jEliminarGA;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableGA;
    private javax.swing.JTextField jText2GA;
    private javax.swing.JTextField jText3GA;
    private javax.swing.JTextField jTextGA;
    // End of variables declaration//GEN-END:variables
}

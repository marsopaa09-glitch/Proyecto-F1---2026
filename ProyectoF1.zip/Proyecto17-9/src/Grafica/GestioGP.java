
package Grafica;

import Logica.Persistenciaa;
import Logica.Circuito;
import Logica.Fachada;
import Logica.Temporada;
import Logica.GranPremio;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestioGP extends javax.swing.JFrame {
    
private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestioGP.class.getName());

    public GestioGP() {
        initComponents();
        cargarCircuitos();
        cargarTemporadas();
        cargarTabla();
       
    }
    
    private void cargarCircuitos() {

    jComboGPRE.removeAllItems();

    for (Circuito circuito : Fachada.getInstancia().obtenerCircuitos()) {
        jComboGPRE.addItem(circuito.getNombre());
    }
    }
    private void cargarTemporadas() {

    jCombo2GPRE.removeAllItems();

    for (Temporada temporada : Fachada.getInstancia().obtenerTemporadas()) {
        jCombo2GPRE.addItem(String.valueOf(temporada.getAnio()));
    }
    
}
    private void cargarTabla() {
        if (jTableGPRE == null) return;
        
        DefaultTableModel modelo = (DefaultTableModel) jTableGPRE.getModel();
        modelo.setRowCount(0);

        if (Fachada.getInstancia().obtenerTemporadas() != null) {
            for (Temporada temporada : Fachada.getInstancia().obtenerTemporadas()) {
                if (temporada != null && temporada.obtenerGrandesPremios() != null) {
                    for (GranPremio gp : temporada.obtenerGrandesPremios()) {
                        if (gp != null) {
                            Circuito circ = gp.getCircuito(); 
                            String nombreCircuito = circ != null ? circ.getNombre() : "";
                            String fechaStr = gp.getFecha() != null ? gp.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "";

                            modelo.addRow(new Object[]{
                                gp.getIdentificador(),
                                gp.getNombre(),
                                fechaStr,
                                nombreCircuito,
                                temporada.getAnio()
                            });
                        }
                    }
                }
            }
        }
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextGPRE = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jText2GPRE = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jCombo2GPRE = new javax.swing.JComboBox<>();
        jButtonGPRE = new javax.swing.JButton();
        jButton2GPRE = new javax.swing.JButton();
        jButton3GPRE = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableGPRE = new javax.swing.JTable();
        jText3GPRE = new javax.swing.JTextField();
        jComboGPRE = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GRANDES PREMIOS");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Identificador:");

        jTextGPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Nombre,");

        jText2GPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jText2GPRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jText2GPREActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Fecha:");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Circuito:");

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel6.setText("Temporada:");

        jCombo2GPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jButtonGPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButtonGPRE.setText("Agregar");
        jButtonGPRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGPREActionPerformed(evt);
            }
        });

        jButton2GPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton2GPRE.setText("Editar");
        jButton2GPRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2GPREActionPerformed(evt);
            }
        });

        jButton3GPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton3GPRE.setText("Eliminar");
        jButton3GPRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3GPREActionPerformed(evt);
            }
        });

        jTableGPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jTableGPRE.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Identificador", "Nombre", "Fecha", "Circuito", "Temporada"
            }
        ));
        jTableGPRE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableGPREMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableGPRE);

        jText3GPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jText3GPRE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jText3GPREActionPerformed(evt);
            }
        });

        jComboGPRE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jButtonGPRE)
                        .addGap(54, 54, 54)
                        .addComponent(jButton2GPRE)
                        .addGap(64, 64, 64)
                        .addComponent(jButton3GPRE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCombo2GPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTextGPRE)
                                .addComponent(jText2GPRE)
                                .addComponent(jText3GPRE, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboGPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextGPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jText2GPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jText3GPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboGPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jCombo2GPRE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGPRE)
                    .addComponent(jButton2GPRE)
                    .addComponent(jButton3GPRE))
                .addGap(54, 54, 54)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGPREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGPREActionPerformed

        try {
            int identificador = Integer.parseInt(jTextGPRE.getText());
            String nombre = jText2GPRE.getText();

            // Parsea la fecha y verifica que el año coincida con la temporada seleccionada
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fecha = LocalDate.parse(jText3GPRE.getText(), formato);
            int anioTemporada = Integer.parseInt(jCombo2GPRE.getSelectedItem().toString());
            
            if (fecha.getYear() != anioTemporada) {
                JOptionPane.showMessageDialog(this, "La fecha debe corresponder al año de la temporada seleccionada.");
                return;
            }

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresá el nombre del Gran Premio.");
                return;
            }

            if (jComboGPRE.getSelectedItem() == null || jCombo2GPRE.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Seleccioná un circuito y una temporada.");
                return;
            }

            // Busca las instancias de Circuito y Temporada elegidas en los ComboBox
            Circuito circuitoSeleccionado = null;
            for (Circuito circuito : Fachada.getInstancia().obtenerCircuitos()) {
                if (circuito.getNombre().equals(jComboGPRE.getSelectedItem().toString())) {
                    circuitoSeleccionado = circuito;
                    break;
                }
            }

            Temporada temporadaSeleccionada = null;
            for (Temporada temporada : Fachada.getInstancia().obtenerTemporadas()) {
                if (temporada.getAnio() == anioTemporada) {
                    temporadaSeleccionada = temporada;
                    break;
                }
            }

            if (circuitoSeleccionado == null || temporadaSeleccionada == null) {
                JOptionPane.showMessageDialog(this, "No se encontró el circuito o la temporada.");
                return;
            }

            // Crea el objeto GP y lo agrega a la lógica
            GranPremio granPremio = new GranPremio(identificador, nombre, fecha);
            granPremio.asignarCircuito(circuitoSeleccionado);
            Fachada.getInstancia().agregarGranPremio(granPremio, temporadaSeleccionada);
            
            // Envía los datos formateados a la Base de Datos mediante la Persistencia
            String datosGP = identificador + ":" + nombre + ":" + fecha.format(formato) + ":" + circuitoSeleccionado.getNombre() + ":" + temporadaSeleccionada.getAnio();
            try {
                Logica.Persistenciaa.EjecutarSentenciaGranPremio(datosGP);
                System.out.println("Gran Premio enviado a la BD con éxito.");
            } catch (Exception e) {
                System.out.println("Error al guardar Gran Premio en la BD: " + e.getMessage());
            }

            // Refresca la tabla y limpia los campos de texto
            cargarTabla();
            jTextGPRE.setText("");
            jText2GPRE.setText("");
            jText3GPRE.setText("");
            jTableGPRE.clearSelection();

            JOptionPane.showMessageDialog(this, "Gran Premio agregado correctamente.");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El identificador debe ser un número.");
        } catch (java.time.format.DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "La fecha debe tener el formato dd/MM/yyyy.");
        }
    
        
    }//GEN-LAST:event_jButtonGPREActionPerformed

    private void jButton2GPREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2GPREActionPerformed

                                                 
        // Obtiene la fila seleccionada de la tabla visual
        int fila = jTableGPRE.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un Gran Premio de la tabla.");
            return;
        }

        try {
            int identificador = Integer.parseInt(jTextGPRE.getText());
            String nombre = jText2GPRE.getText();

            java.time.format.DateTimeFormatter formato = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
            java.time.LocalDate fecha = java.time.LocalDate.parse(jText3GPRE.getText(), formato);
            int anioTemporada = Integer.parseInt(jCombo2GPRE.getSelectedItem().toString());

            Circuito circuitoSeleccionado = null;
            for (Circuito circuito : Fachada.getInstancia().obtenerCircuitos()) {
                if (circuito.getNombre().equals(jComboGPRE.getSelectedItem().toString())) {
                    circuitoSeleccionado = circuito;
                    break;
                }
            }

            Temporada temporadaSeleccionada = null;
            for (Temporada temporada : Fachada.getInstancia().obtenerTemporadas()) {
                if (temporada.getAnio() == anioTemporada) {
                    temporadaSeleccionada = temporada;
                    break;
                }
            }

            GranPremio granPremio = new GranPremio(identificador, nombre, fecha);
            granPremio.asignarCircuito(circuitoSeleccionado);

            int identificadorAnterior = Integer.parseInt(jTableGPRE.getValueAt(fila, 0).toString());
            
            // Envía la actualización a la Base de Datos mediante la Persistencia
            String datosGP = identificador + ":" + nombre + ":" + fecha.format(formato) + ":" + (circuitoSeleccionado != null ? circuitoSeleccionado.getNombre() : "") + ":" + anioTemporada;
            try {
                Persistenciaa.EjecutarSentenciaGranPremio(datosGP);
            } catch (Exception e) {
                javax.swing.JOptionPane.showMessageDialog(this, "Error al actualizar en la Base de Datos: " + e.getMessage());
                return;
            }

            // Actualiza en memoria local (Fachada)
            Fachada.getInstancia().modificarGranPremio(identificadorAnterior, granPremio);

            // Refresca la tabla y limpia los campos de texto
            cargarTabla();
            javax.swing.JOptionPane.showMessageDialog(this, "Gran Premio modificado correctamente.");
            
            jTextGPRE.setText("");
            jText2GPRE.setText("");
            jText3GPRE.setText("");
            jTableGPRE.clearSelection();

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error en los datos de edición: " + e.getMessage());
        }
    
        
    }//GEN-LAST:event_jButton2GPREActionPerformed

    private void jText2GPREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jText2GPREActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jText2GPREActionPerformed

    private void jText3GPREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jText3GPREActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jText3GPREActionPerformed

    private void jTableGPREMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGPREMouseClicked
    int fila = jTableGPRE.getSelectedRow();

    if (fila != -1) {

    jTextGPRE.setText( jTableGPRE.getValueAt(fila, 0).toString()
    );

    jText2GPRE.setText(jTableGPRE.getValueAt(fila, 1).toString()
    );

    jText3GPRE.setText(jTableGPRE.getValueAt(fila, 2).toString()
    );

    jComboGPRE.setSelectedItem(jTableGPRE.getValueAt(fila, 3).toString()
    );

    jCombo2GPRE.setSelectedItem(jTableGPRE.getValueAt(fila, 4).toString()
    );
}
    }//GEN-LAST:event_jTableGPREMouseClicked

    private void jButton3GPREActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3GPREActionPerformed

        int fila = jTableGPRE.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un Gran Premio de la tabla.");
            return;
        }

        int identificador = Integer.parseInt(jTableGPRE.getValueAt(fila, 0).toString());

        int confirmar = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "¿Seguro que querés eliminar el Gran Premio?", "Confirmar eliminación",
                javax.swing.JOptionPane.YES_NO_OPTION
        );

        if (confirmar == javax.swing.JOptionPane.YES_OPTION) {
            // 1. Eliminamos físicamente de la Base de Datos
            try {
                String sentenciaEliminar = "ELIMINAR:" + identificador;
                Persistenciaa.EjecutarSentenciaGranPremio(sentenciaEliminar);
            } catch (Exception e) {
                System.out.println("Error al eliminar en BD: " + e.getMessage());
            }

            // 2. Eliminamos de la memoria local de forma segura
            GranPremio granPremio = Fachada.getInstancia().buscarGranPremio(identificador);
            if (granPremio != null) {
                try {
                    Fachada.getInstancia().eliminarGranPremio(granPremio);
                } catch (Exception e) {
                    // Si la fachada requiere desvincular la temporada previamente
                    System.out.println("Aviso en memoria: " + e.getMessage());
                }
            }

            cargarTabla();
            jTextGPRE.setText("");
            jText2GPRE.setText("");
            jText3GPRE.setText("");
            jTableGPRE.clearSelection();

            javax.swing.JOptionPane.showMessageDialog(this, "Gran Premio eliminado correctamente.");
        }
    
        
    }//GEN-LAST:event_jButton3GPREActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestioGP().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2GPRE;
    private javax.swing.JButton jButton3GPRE;
    private javax.swing.JButton jButtonGPRE;
    private javax.swing.JComboBox<String> jCombo2GPRE;
    private javax.swing.JComboBox<String> jComboGPRE;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableGPRE;
    private javax.swing.JTextField jText2GPRE;
    private javax.swing.JTextField jText3GPRE;
    private javax.swing.JTextField jTextGPRE;
    // End of variables declaration//GEN-END:variables
}

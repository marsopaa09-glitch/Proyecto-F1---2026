
package Grafica;
import Logica.Temporada;
import Logica.Fachada;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
        

/**
 *
 * @author 58153596
 */
public class GestionTemporada extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionTemporada.class.getName());

    
    public GestionTemporada() {
        initComponents();
        
        // Agrupamos los RadioButtons para que sean excluyentes (o activa o finalizada)
        javax.swing.ButtonGroup grupoEstado = new javax.swing.ButtonGroup();
        grupoEstado.add(jRadioButtonGT);
        grupoEstado.add(jRadioButton2GT);
        jRadioButtonGT.setSelected(true); // Seleccionada por defecto
        
        cargarTabla(); // Carga los datos en la tabla al abrir
    }
    
    
    private boolean validarFechas(int anio) {
        
    String fechaInicio = jTextGT.getText();

    try {
        LocalDate inicio = LocalDate.parse(
                fechaInicio,
                DateTimeFormatter.ofPattern("dd/MM/yyyy")
        );

        if (inicio.getYear() != anio) {
            JOptionPane.showMessageDialog(this, "Tenés que ingresar una fecha correspondiente al año de la temporada seleccionada."
            );
            return false;
        }

        return true;

    } catch (DateTimeParseException e) {
        JOptionPane.showMessageDialog(this, "Ingresá una fecha válida con el formato dd/MM/yyyy."
        );
        return false;
    }
}    
   private void cargarTabla() {
        if (jTable1 == null) return;
        
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
        modelo.setRowCount(0);

        if (Fachada.getInstancia().obtenerTemporadas() != null) {
            for (Temporada temp : Fachada.getInstancia().obtenerTemporadas()) {
                if (temp != null) {
                    String estadoStr = temp.isActiva() ? "Activa" : "Finalizada";
                    modelo.addRow(new Object[]{
                        temp.getAnio(),
                        temp.getFechaInicio(),
                        temp.getFechaFin(),
                        estadoStr
                    });
                }
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboGT = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jTextGT = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jText2GT = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jRadioButtonGT = new javax.swing.JRadioButton();
        jRadioButton2GT = new javax.swing.JRadioButton();
        jButtonGT = new javax.swing.JButton();
        jButton2GT = new javax.swing.JButton();
        jButton3GE = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jLabel6.setText("jLabel6");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GÉSTION DE TEMPORADAS");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Temporada:");

        jComboGT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jComboGT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026" }));

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Fecha Inicio:");

        jTextGT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Fecha Fin:");

        jText2GT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Estado:");

        jRadioButtonGT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jRadioButtonGT.setText("Activa");

        jRadioButton2GT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jRadioButton2GT.setText("Finalizada");

        jButtonGT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButtonGT.setText("Crear");
        jButtonGT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGTActionPerformed(evt);
            }
        });

        jButton2GT.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton2GT.setText("Editar");
        jButton2GT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2GTActionPerformed(evt);
            }
        });

        jButton3GE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton3GE.setText("Eliminar");
        jButton3GE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3GEActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Temporadas", "Inicio", "Fin", "Estado"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(jComboGT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTextGT, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
                                            .addComponent(jText2GT)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(jRadioButtonGT)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jRadioButton2GT))))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jButtonGT)
                        .addGap(31, 31, 31)
                        .addComponent(jButton2GT)
                        .addGap(29, 29, 29)
                        .addComponent(jButton3GE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(135, 135, 135)
                        .addComponent(jLabel1)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboGT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextGT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jText2GT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jRadioButtonGT)
                    .addComponent(jRadioButton2GT))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGT)
                    .addComponent(jButton2GT)
                    .addComponent(jButton3GE))
                .addGap(55, 55, 55)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(84, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGTActionPerformed
                                       

        int anio = Integer.parseInt(jComboGT.getSelectedItem().toString());

        String fechaInicio = jTextGT.getText();
        String fechaFin = jText2GT.getText();

        boolean activa = jRadioButtonGT.isSelected();

        if (!validarFechas(anio)) {
            return;
        }

        Temporada existente = Fachada.getInstancia().buscarTemporada(anio);

        if (existente != null) {
            Temporada temporadaMod = new Temporada(anio, fechaInicio, fechaFin, activa);
            Fachada.getInstancia().modificarTemporada(temporadaMod);

            String estado = activa ? "Activa" : "Finalizada";
            String datosTemporada = anio + ":" + fechaInicio + ":" + fechaFin + ":" + estado;
            try {
                Logica.Persistenciaa.EjecutarSentenciaTemporada(datosTemporada);
            } catch (Exception e) {
                System.out.println("Error al actualizar temporada en BD: " + e.getMessage());
            }

            JOptionPane.showMessageDialog(this, "La temporada ya existía, se actualizó correctamente.");
        } else {
            Temporada temporada = new Temporada(anio, fechaInicio, fechaFin, activa);
            Fachada.getInstancia().agregarTemporada(temporada);

            String estado = activa ? "Activa" : "Finalizada";
            String datosTemporada = anio + ":" + fechaInicio + ":" + fechaFin + ":" + estado;
            try {
                Logica.Persistenciaa.EjecutarSentenciaTemporada(datosTemporada);
                System.out.println("Temporada guardada en la base de datos.");
            } catch (Exception e) {
                System.out.println("Error al persistir temporada: " + e.getMessage());
            }

            JOptionPane.showMessageDialog(this, "Temporada creada correctamente.");
        }

        jTextGT.setText("");
        jText2GT.setText("");
        
        cargarTabla(); // <--- ¡ESTO FALTABA! Actualiza la tabla automáticamente al crear o modificar.

    

    }//GEN-LAST:event_jButtonGTActionPerformed

    private void jButton2GTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2GTActionPerformed

    
  int fila = jTable1.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccioná una temporada de la tabla para editar.");
            return;
        }

        int anio = Integer.parseInt(jComboGT.getSelectedItem().toString());
        String fechaInicio = jTextGT.getText();
        String fechaFin = jText2GT.getText();
        boolean activa = jRadioButtonGT.isSelected();

        if (!validarFechas(anio)) {
            return;
        }

        Temporada temporada = new Temporada(anio, fechaInicio, fechaFin, activa);
        Fachada.getInstancia().modificarTemporada(temporada);

        String estado = activa ? "Activa" : "Finalizada";
        
        String datosTemporada = anio + ":" + fechaInicio + ":" + fechaFin + ":" + estado;
        try {
            Logica.Persistenciaa.EjecutarSentenciaTemporada(datosTemporada);
        } catch (Exception e) {
            System.out.println("Error al actualizar temporada en BD: " + e.getMessage());
        }

        jTable1.setValueAt(anio, fila, 0);
        jTable1.setValueAt(fechaInicio, fila, 1);
        jTable1.setValueAt(fechaFin, fila, 2);
        jTable1.setValueAt(estado, fila, 3);

        JOptionPane.showMessageDialog(this, "Temporada modificada correctamente.");
    
    }//GEN-LAST:event_jButton2GTActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
    int fila = jTable1.getSelectedRow();

    if (fila != -1) {

    jComboGT.setSelectedItem(
            jTable1.getValueAt(fila, 0).toString()
    );

    jTextGT.setText(
            jTable1.getValueAt(fila, 1).toString()
    );

    jText2GT.setText(
            jTable1.getValueAt(fila, 2).toString()
    );

    String estado = jTable1.getValueAt(fila, 3).toString();

    if (estado.equals("Activa")) {
        jRadioButtonGT.setSelected(true);
        jRadioButton2GT.setSelected(false);
    } else {
        jRadioButtonGT.setSelected(false);
        jRadioButton2GT.setSelected(true);
    }
}
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton3GEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3GEActionPerformed

        int fila = jTable1.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccioná una temporada de la tabla para eliminar.");
            return;
        }

        int anio = Integer.parseInt(jTable1.getValueAt(fila, 0).toString());

        int confirmar = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que querés eliminar esta temporada?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmar == JOptionPane.YES_OPTION) {
            try {
                Fachada.getInstancia().eliminarTemporada(anio);
                
                try {
                    String sentenciaEliminar = "ELIMINAR:" + anio;
                    Logica.Persistenciaa.EjecutarSentenciaTemporada(sentenciaEliminar);
                } catch (Exception e) {
                    System.out.println("Error al eliminar temporada en BD: " + e.getMessage());
                }

                DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
                modelo.removeRow(fila);

                jTextGT.setText("");
                jText2GT.setText("");
                jTable1.clearSelection();

                JOptionPane.showMessageDialog(this, "Temporada eliminada correctamente.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    
        
    }//GEN-LAST:event_jButton3GEActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionTemporada().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2GT;
    private javax.swing.JButton jButton3GE;
    private javax.swing.JButton jButtonGT;
    private javax.swing.JComboBox<String> jComboGT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JRadioButton jRadioButton2GT;
    private javax.swing.JRadioButton jRadioButtonGT;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jText2GT;
    private javax.swing.JTextField jTextGT;
    // End of variables declaration//GEN-END:variables
}

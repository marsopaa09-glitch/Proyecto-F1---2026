
package Grafica;

import Logica.Escuderia;
import Logica.Fachada;
import Logica.Resultado;
import Logica.Temporada;
import Logica.Piloto;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Consultas extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Consultas.class.getName());


    public Consultas() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        cargarTemporadas();

    }
 
    
    public Consultas(String tipoConsulta){
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        
        cargarTemporadas();
        
        jComboConsultas.setSelectedItem(tipoConsulta);
    }
    
    public void cargarTemporadas(){
        
        jComboTemporada.removeAllItems();
        for(Temporada temporada : Fachada.getInstancia().obtenerTemporadas()){
            jComboTemporada.addItem(String.valueOf(temporada.getAnio()));
        
    }
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboConsultas = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jComboTemporada = new javax.swing.JComboBox<>();
        jButtonBuscar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableConsulta = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("CONSULTAS");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Consulta:");

        jComboConsultas.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jComboConsultas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Resultados de Grandes Premios", "Clasificación de Pilotos", "Victorias por Escudería", "Vuelta Rápida" }));

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Temporada:");

        jComboTemporada.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jButtonBuscar.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButtonBuscar.setText("Buscar");
        jButtonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("RESULTADO:");

        jTableConsulta.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jTableConsulta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Posición", "Piloto", "Escudería", "Puntos"
            }
        ));
        jScrollPane1.setViewportView(jTableConsulta);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboConsultas, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboTemporada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(144, 144, 144)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(jButtonBuscar)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboConsultas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jComboTemporada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jButtonBuscar)
                .addGap(56, 56, 56)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBuscarActionPerformed
    DefaultTableModel modelo = (DefaultTableModel) jTableConsulta.getModel();
    modelo.setRowCount(0);

    if (jComboTemporada.getSelectedItem() == null) {
    JOptionPane.showMessageDialog(this, "Seleccioná una temporada.");
    return;
    }

    int anio = Integer.parseInt(jComboTemporada.getSelectedItem().toString());
    Temporada temporada = Fachada.getInstancia().buscarTemporada(anio);

   if (temporada == null) {
       return;
   }

   String consulta = jComboConsultas.getSelectedItem().toString();

   String tituloUltimaColumna= "Puntos";

   if (consulta.equals("Victorias por Escudería")){
       tituloUltimaColumna = "Victorias";
    
   }else if (consulta.equals("Vuelta Rápida")){
    tituloUltimaColumna = "Tiempo";
   }
   
   modelo.setColumnIdentifiers(new Object[]{
    "Posición", "Piloto", "Escudería", tituloUltimaColumna
   });





List<Resultado> resultados =
        Fachada.getInstancia().obtenerResultadosTemporada(temporada);

if (consulta.equals("Resultados de Grandes Premios")) {

    for (Resultado r : resultados) {
        String escuderia = "";

        if (r.obtenerAuto() != null && r.obtenerAuto().obtenerEscuderia() != null) {
            escuderia = r.obtenerAuto().obtenerEscuderia().getNombre();
        }

        modelo.addRow(new Object[]{
            r.getPosicion(),
            r.obtenerPiloto().getNombre() + " " + r.obtenerPiloto().getApellido(),
            escuderia,
            r.getPuntos()
        });
    }

} else if (consulta.equals("Clasificación de Pilotos")) {

    
    List<Piloto> pilotos = Fachada.getInstancia().obtenerClasificacionPilotos();    
    for (Piloto piloto : pilotos) {
        double puntos = 0;

        for (Resultado r : resultados) {
            if (r.obtenerPiloto() == piloto) {
                puntos += r.getPuntos();
            }
        }

        modelo.addRow(new Object[]{
            modelo.getRowCount() + 1,
            piloto.getNombre() + " " + piloto.getApellido(),
            "",
            puntos
        });
    }

} else if (consulta.equals("Victorias por Escudería")) {

    for (Escuderia escuderia : Fachada.getInstancia().obtenerEscuderias()) {
        int victorias = 0;

        for (Resultado r : resultados) {
            if (r.getPosicion() == 1
                    && r.obtenerAuto() != null
                    && r.obtenerAuto().obtenerEscuderia() != null
                    && r.obtenerAuto().obtenerEscuderia().getIdentificador()
                    == escuderia.getIdentificador()) {
                victorias++;
            }
        }

        if (victorias > 0) {
            modelo.addRow(new Object[]{
                "",
                "",
                escuderia.getNombre(),
                victorias
            });
        }
    }

} else if (consulta.equals("Vuelta Rápida")) {

    Resultado masRapido = null;

    for (Resultado r : resultados) {
        if (masRapido == null
                || r.getTiempoPorVuelta() < masRapido.getTiempoPorVuelta()) {
            masRapido = r;
        }
    }

    if (masRapido != null) {
        String escuderia = "";

        if (masRapido.obtenerAuto() != null
                && masRapido.obtenerAuto().obtenerEscuderia() != null) {
            escuderia = masRapido.obtenerAuto().obtenerEscuderia().getNombre();
        }

        modelo.addRow(new Object[]{
            masRapido.getPosicion(),
            masRapido.obtenerPiloto().getNombre() + " "
                    + masRapido.obtenerPiloto().getApellido(),
            escuderia,
            masRapido.getTiempoPorVuelta()
        });
    }
}
    }//GEN-LAST:event_jButtonBuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Consultas().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBuscar;
    private javax.swing.JComboBox<String> jComboConsultas;
    private javax.swing.JComboBox<String> jComboTemporada;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableConsulta;
    // End of variables declaration//GEN-END:variables
}

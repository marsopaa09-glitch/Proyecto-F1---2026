
package Grafica;

import Logica.Persistenciaa;
import Logica.Escuderia;
import Logica.Fachada;
import Logica.ProveedorMotor;
import Logica.Temporada;
import javax.swing.JOptionPane;

/**
 *
 * @author 58153596
 */
public class GestionEscuderia extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionEscuderia.class.getName());

  
    public GestionEscuderia() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        cargarTabla();
        cargarProveedoresMotor();
        cargarTemporadas();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextGE = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jComboGE = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jCombo2GE = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jCheckGE = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        jCombo3GE = new javax.swing.JComboBox<>();
        jAgregarGE = new javax.swing.JButton();
        jEditarGE = new javax.swing.JButton();
        jEliminarGE = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jText2GE = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GÉSTION DE ESCUDERÍAS");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Escudería:");

        jTextGE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("País:");

        jComboGE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jComboGE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alemania", "Austria", "Canadá", "Estados Unidos", "Francia", "India", "Irlanda", "Italia", "Japón", "Países Bajos", "Reino Unido", "Rusia", "Sudáfrica", "Suiza", "Uruguay" }));

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Proveedor:");

        jCombo2GE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Estado:");

        jCheckGE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jCheckGE.setText("Activa");

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel6.setText("Temporada");

        jCombo3GE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jCombo3GE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2026", "2025", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010" }));

        jAgregarGE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jAgregarGE.setText("Agregar");
        jAgregarGE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregarGEActionPerformed(evt);
            }
        });

        jEditarGE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jEditarGE.setText("Editar");
        jEditarGE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEditarGEActionPerformed(evt);
            }
        });

        jEliminarGE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jEliminarGE.setText("Eliminar");
        jEliminarGE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminarGEActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Escudería", "País", "Proveedor", "Estado", "Temporada", "Identificador"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel7.setText("N° de Chasis");

        jText2GE.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addComponent(jAgregarGE)
                                .addGap(88, 88, 88)
                                .addComponent(jEditarGE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jEliminarGE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel5))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jComboGE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextGE, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                                        .addComponent(jCombo2GE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jCheckGE)
                                        .addComponent(jCombo3GE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jText2GE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(49, 49, 49))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 505, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextGE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jText2GE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jComboGE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jCombo2GE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jCheckGE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jCombo3GE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAgregarGE)
                    .addComponent(jEditarGE)
                    .addComponent(jEliminarGE))
                .addGap(34, 34, 34)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jAgregarGEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregarGEActionPerformed
        
        String nombreEscuderia = jTextGE.getText().trim();
        String numeroChasisStr = jText2GE.getText().trim();

        if (nombreEscuderia.isEmpty() || numeroChasisStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completá el nombre de la escudería y el número de chasis.");
            return;
        }

        if (jCombo2GE.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Seleccioná un proveedor de motor.");
            return;
        }
        
        int numeroChasis;
        try {
            numeroChasis = Integer.parseInt(numeroChasisStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El número de chasis debe ser un valor numérico.");
            return;
        }

        String proveedor = jCombo2GE.getSelectedItem().toString();
        int idProveedor = 1; 
        String pais = jComboGE.getSelectedItem().toString();
        boolean activa = jCheckGE.isSelected();
        int temporada = Integer.parseInt(jCombo3GE.getSelectedItem().toString());

        Escuderia escuderia = new Escuderia(numeroChasis, nombreEscuderia, pais, proveedor, activa, temporada);
        Fachada.getInstancia().agregarEscuderia(escuderia);

        try {
            String datosEscuderia = nombreEscuderia + ":" + idProveedor + ":" + numeroChasis;
            Persistenciaa.EjecutarSentenciaEscuderia(datosEscuderia);
        } catch (Exception e) {
            System.out.println("Error al guardar escudería en la BD: " + e.getMessage());
        }
        
        cargarTabla();
        JOptionPane.showMessageDialog(this, "¡Escudería guardada con éxito!");
        
        jTextGE.setText("");
        jText2GE.setText("");
        jCheckGE.setSelected(false);
                                           

    

    }//GEN-LAST:event_jAgregarGEActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked

    int fila = jTable1.getSelectedRow();

    if (fila != -1) {

        jTextGE.setText(jTable1.getValueAt(fila, 0).toString());
        jComboGE.setSelectedItem(jTable1.getValueAt(fila, 1).toString());
        jCombo2GE.setSelectedItem(jTable1.getValueAt(fila, 2).toString());
        jCheckGE.setSelected(jTable1.getValueAt(fila, 3).toString().equals("Activa"));
        jCombo3GE.setSelectedItem(jTable1.getValueAt(fila, 4).toString());
        jText2GE.setText(jTable1.getValueAt(fila, 5).toString());
   
    }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jEditarGEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEditarGEActionPerformed

        int fila = jTable1.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccioná una escudería de la tabla para editar.");
            return;
        }

        int identificadorAnterior = Integer.parseInt(jTable1.getValueAt(fila, 5).toString());
        String numeroChasisStr = jText2GE.getText().trim();
        String nombre = jTextGE.getText().trim();

        if (nombre.isEmpty() || numeroChasisStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completá el nombre y el número de chasis.");
            return;
        }

        int identificadorNuevo;
        try {
            identificadorNuevo = Integer.parseInt(numeroChasisStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El número de chasis debe ser un valor numérico.");
            return;
        }

        String pais = jComboGE.getSelectedItem().toString();
        String proveedor = jCombo2GE.getSelectedItem().toString();
        boolean activa = jCheckGE.isSelected();
        int temporada = Integer.parseInt(jCombo3GE.getSelectedItem().toString());

        Escuderia escuderia = Fachada.getInstancia().buscarEscuderia(identificadorAnterior);

        if (escuderia == null) {
            JOptionPane.showMessageDialog(this, "No se encontró la escudería en el sistema.");
            return;
        }

        escuderia.modificarDatos(nombre, pais, proveedor, activa, temporada);
        escuderia.modificarIdentificador(identificadorNuevo);
        Fachada.getInstancia().modificarEscuderia(escuderia);

        cargarTabla();
        JOptionPane.showMessageDialog(this, "Escudería modificada correctamente.");
        
        jTextGE.setText("");
        jText2GE.setText("");
        jCheckGE.setSelected(false);
        jTable1.clearSelection();
    
      
    }//GEN-LAST:event_jEditarGEActionPerformed

    private void jEliminarGEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminarGEActionPerformed

        int fila = jTable1.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccioná una escudería de la tabla.");
            return;
        }

        int identificador = Integer.parseInt(jTable1.getValueAt(fila, 5).toString());
        Escuderia escuderia = Fachada.getInstancia().buscarEscuderia(identificador);

        if (escuderia == null) {
            JOptionPane.showMessageDialog(this, "No se encontró la escudería.");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(this, 
            "¿Estás seguro de que querés eliminar esta escudería?", 
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmar == JOptionPane.YES_OPTION) {
            Fachada.getInstancia().eliminarEscuderia(escuderia);

            try {
                String sentenciaEliminar = "ELIMINAR:" + identificador;
                Persistenciaa.EjecutarSentencia(sentenciaEliminar);
            } catch (Exception e) {
                System.out.println("Error al eliminar en BD: " + e.getMessage());
            }

            cargarTabla();

            jTextGE.setText("");
            jText2GE.setText("");
            jCheckGE.setSelected(false);
            jTable1.clearSelection();

            JOptionPane.showMessageDialog(this, "Escudería eliminada correctamente.");
        }
    

    }//GEN-LAST:event_jEliminarGEActionPerformed
    
    public void cargarTabla() {

    javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) jTable1.getModel();

    modelo.setRowCount(0);

    for (Escuderia escuderia : Fachada.getInstancia().obtenerEscuderias()) {

        modelo.addRow(new Object[]{
            escuderia.getNombre(),
            escuderia.getPais(),
            escuderia.getProveedor(),
            escuderia.isActiva() ? "Activa" : "Inactiva",
            escuderia.getTemporada(),
            escuderia.getIdentificador()
        });
    }
}
    private void cargarProveedoresMotor() {
        // Limpio el combo por las dudas
        jCombo2GE.removeAllItems();

        // Intento cargar los proveedores desde la fachada y la base de datos
        try {
            for (ProveedorMotor proveedor : Fachada.getInstancia().obtenerProveedoresMotor()) {
                jCombo2GE.addItem(proveedor.getNombre());
            }
        } catch (Exception e) {
            System.out.println("No se pudieron cargar los proveedores de la base.");
        }

        //Tabla de Provedores 
        if (jCombo2GE.getItemCount() == 0) {
            jCombo2GE.addItem("Mercedes");
            jCombo2GE.addItem("Ferrari");
            jCombo2GE.addItem("Honda");
            jCombo2GE.addItem("Renault");
            jCombo2GE.addItem("Audi");
            jCombo2GE.addItem("Ford");
            jCombo2GE.addItem("Porsche");
            jCombo2GE.addItem("BMW");
            jCombo2GE.addItem("Toyota");
            jCombo2GE.addItem("Tag Heuer");
        }
    }
    public void cargarTemporadas() {
    // Limpio el combo por las dudas
    jCombo3GE.removeAllItems();
    
    // Intento cargar los años desde la fachada/base de datos
    try {
        for (Temporada temporada : Fachada.getInstancia().obtenerTemporadas()) {
            jCombo3GE.addItem(String.valueOf(temporada.getAnio()));
        }
    } catch (Exception e) {
        System.out.println("No se pudieron cargar de la base, usando valores por defecto.");
    }
    
    // Si por alguna razón la base de datos no devuelve nada, 
    // le metemos los años a mano para que nunca quede vacío al correr el programa
    if (jCombo3GE.getItemCount() == 0) {
        for (int anio = 2026; anio >= 2010; anio--) {
            jCombo3GE.addItem(String.valueOf(anio));
        }
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jAgregarGE;
    private javax.swing.JCheckBox jCheckGE;
    private javax.swing.JComboBox<String> jCombo2GE;
    private javax.swing.JComboBox<String> jCombo3GE;
    private javax.swing.JComboBox<String> jComboGE;
    private javax.swing.JButton jEditarGE;
    private javax.swing.JButton jEliminarGE;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jText2GE;
    private javax.swing.JTextField jTextGE;
    // End of variables declaration//GEN-END:variables
}

package Grafica;
import Logica.Persistenciaa;
import Logica.Fachada;
import Logica.Proveedor;
import Logica.ProveedorMotor;


public class GestionProveedor extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GestionProveedor.class.getName());

 
    public GestionProveedor() {
        initComponents();
        cargarTabla();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jText2GPRO = new javax.swing.JTextField();
        jText3GPRO = new javax.swing.JTextField();
        jButtonGPRO = new javax.swing.JButton();
        jButton2GPRO = new javax.swing.JButton();
        jButton3GPRO = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableGPRO = new javax.swing.JTable();
        jComboGPRO = new javax.swing.JComboBox<>();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        jLabel1.setText("GÉSTION PROVEEDOR");

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Tipo de proveedor");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Número de chasis(CHG001)");

        jButtonGPRO.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButtonGPRO.setText("Agregar");
        jButtonGPRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGPROActionPerformed(evt);
            }
        });

        jButton2GPRO.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton2GPRO.setText("Editar");
        jButton2GPRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2GPROActionPerformed(evt);
            }
        });

        jButton3GPRO.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jButton3GPRO.setText("Eliminar");
        jButton3GPRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3GPROActionPerformed(evt);
            }
        });

        jTableGPRO.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Identificador", "Nombre", "Tipo", "Número de chasis"
            }
        ));
        jTableGPRO.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableGPROMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableGPRO);

        jComboGPRO.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Motor ", "Indumentaria" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(jButtonGPRO)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboGPRO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jText2GPRO, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                                    .addComponent(jText3GPRO)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jButton2GPRO)
                                .addGap(72, 72, 72)
                                .addComponent(jButton3GPRO))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(158, 158, 158)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jText2GPRO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboGPRO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jText3GPRO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonGPRO)
                    .addComponent(jButton2GPRO)
                    .addComponent(jButton3GPRO))
                .addGap(43, 43, 43)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonGPROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGPROActionPerformed

        String nombre = jText2GPRO.getText().trim();
        String tipo = jComboGPRO.getSelectedItem().toString().trim();
        String numeroChasis = jText3GPRO.getText().trim();

        if (nombre.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Completá el nombre del proveedor.");
            return;
        }

        if (tipo.equals("Motor") && numeroChasis.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Completá el número de chasis para los proveedores de motor.");
            return;
        }

        // Generar un ID aleatorio (entre 1000 y 99999)
        int identificador = (int) (Math.random() * 90000) + 1000;

        // Intentar guardar en la Base de Datos PRIMERO (respetando el formato que la BD lee)
        String datosProveedor = identificador + ":" + nombre + ":" + tipo + ":" + (numeroChasis.isEmpty() ? "N/A" : numeroChasis);
        try {
            Persistenciaa.EjecutarSentenciaProveedor(datosProveedor);
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar en la Base de Datos: " + e.getMessage());
            return;
        }

        // Guardar en memoria (Fachada)
        if (tipo.equals("Motor")) {
            ProveedorMotor proveedor = new ProveedorMotor(identificador, nombre, numeroChasis);
            Fachada.getInstancia().agregarProveedor(proveedor);
        } else {
            Proveedor proveedor = new Proveedor(identificador, nombre);
            Fachada.getInstancia().agregarProveedor(proveedor);
        }

        cargarTabla();
        javax.swing.JOptionPane.showMessageDialog(this, "¡Proveedor agregado con éxito (ID: " + identificador + ")!");

        jText2GPRO.setText("");
        jText3GPRO.setText("");
        jTableGPRO.clearSelection();
    
    
    }//GEN-LAST:event_jButtonGPROActionPerformed

    private void jTableGPROMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGPROMouseClicked

        int fila = jTableGPRO.getSelectedRow();

        if (fila != -1) {
            jText2GPRO.setText(jTableGPRO.getValueAt(fila, 1).toString());
            jComboGPRO.setSelectedItem(jTableGPRO.getValueAt(fila, 2).toString());
            jText3GPRO.setText(jTableGPRO.getValueAt(fila, 3).toString());
        }
    

    }//GEN-LAST:event_jTableGPROMouseClicked

    private void jButton2GPROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2GPROActionPerformed

                                            
        int fila = jTableGPRO.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un proveedor de la tabla para editar.");
            return;
        }

        int identificador = Integer.parseInt(jTableGPRO.getValueAt(fila, 0).toString());
        String nombre = jText2GPRO.getText().trim();
        String tipo = jComboGPRO.getSelectedItem().toString().trim();
        String numeroChasis = jText3GPRO.getText().trim();

        if (nombre.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Completá el nombre.");
            return;
        }

        if (tipo.equals("Motor") && numeroChasis.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Completá el número de chasis.");
            return;
        }

        // Actualizar en la Base de Datos enviando el formato que la BD interpreta
        String datosProveedor = identificador + ":" + nombre + ":" + tipo + ":" + (numeroChasis.isEmpty() ? "N/A" : numeroChasis);
        try {
            Persistenciaa.EjecutarSentenciaProveedor(datosProveedor);
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al actualizar en la Base de Datos: " + e.getMessage());
            return;
        }

        // Actualizar en memoria
        Proveedor proveedor;
        if (tipo.equals("Motor")) {
            proveedor = new ProveedorMotor(identificador, nombre, numeroChasis);
        } else {
            proveedor = new Proveedor(identificador, nombre);
        }

        Fachada.getInstancia().modificarProveedor(identificador, proveedor);

        cargarTabla();
        javax.swing.JOptionPane.showMessageDialog(this, "Proveedor modificado correctamente.");

        jText2GPRO.setText("");
        jText3GPRO.setText("");
        jTableGPRO.clearSelection();
    

    }//GEN-LAST:event_jButton2GPROActionPerformed

    private void jButton3GPROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3GPROActionPerformed
                                         
        int fila = jTableGPRO.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccioná un proveedor de la tabla para eliminar.");
            return;
        }

        int identificador = Integer.parseInt(jTableGPRO.getValueAt(fila, 0).toString());

        int confirmar = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que querés eliminar este proveedor?",
                "Confirmar eliminación",
                javax.swing.JOptionPane.YES_NO_OPTION
        );

        if (confirmar != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        // Intentar eliminar de la Base de Datos sin enviar texto que rompa el Integer.parseInt
        try {
            // Si la persistencia espera el formato con ceros o un comando numérico, probamos enviando el ID.
            // Si tu base de datos requiere otra cosa para borrar, esto evitará que tire el error de "For input string".
        String sentenciaEliminar = "ELIMINAR:" + identificador;
        Persistenciaa.EjecutarSentenciaProveedor(sentenciaEliminar);
        } catch (Exception e) {
            // Si la base de datos se pone terca con eliminar, al menos borramos de memoria y dejamos seguir
            // (ideal para charlarlo con tus compañeros después si la BD no soporta borrados físicos).
        }

        // Borramos de la memoria (Fachada) y actualizamos la tabla
        Proveedor proveedor = Fachada.getInstancia().buscarProveedor(identificador);
        if (proveedor != null) {
            Fachada.getInstancia().eliminarProveedor(proveedor);
        }

        cargarTabla();

        jText2GPRO.setText("");
        jText3GPRO.setText("");
        jTableGPRO.clearSelection();

        javax.swing.JOptionPane.showMessageDialog(this, "Proveedor eliminado de la interfaz correctamente.");
    

    }//GEN-LAST:event_jButton3GPROActionPerformed
    private void cargarTabla() {

    javax.swing.table.DefaultTableModel modelo =
            (javax.swing.table.DefaultTableModel) jTableGPRO.getModel();

    modelo.setRowCount(0);

    for (Proveedor proveedor :
            Fachada.getInstancia().obtenerProveedores()) {

        String tipo;
        String numeroChasis;

        if (proveedor instanceof ProveedorMotor) {
            tipo = "Motor";
            numeroChasis =
                    ((ProveedorMotor) proveedor).obtenerNumeroChasis();
        } else {
            tipo = "Indumentaria";
            numeroChasis = "";
        }

        modelo.addRow(new Object[]{
            proveedor.getIdentificador(),
            proveedor.getNombre(),
            tipo,
            numeroChasis
        });
    }
}
    

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GestionProveedor().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2GPRO;
    private javax.swing.JButton jButton3GPRO;
    private javax.swing.JButton jButtonGPRO;
    private javax.swing.JComboBox<String> jComboGPRO;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableGPRO;
    private javax.swing.JTextField jText2GPRO;
    private javax.swing.JTextField jText3GPRO;
    // End of variables declaration//GEN-END:variables
}
package Logica;

import Grafica.Login;

public class Main {
    public static void main(String[] args) {
        
        // Verificación rápida de conexión 
        System.out.println("Driver JDBC cargado?: " + Persistenciaa.conectar());

        // Lanzamos la interfaz gráfica principal para que el usuario interactúe
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }
}
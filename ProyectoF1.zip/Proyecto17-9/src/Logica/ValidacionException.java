package Logica;

/**
 * Se lanza cuando un dato o una relación no cumple las reglas del sistema.
 * Es una excepción no verificada (RuntimeException): no obliga a usar try/catch,
 * pero la interfaz puede capturarla y mostrar getMessage() al usuario.
 */
public class ValidacionException extends RuntimeException {

    public ValidacionException(String mensaje) {
        super(mensaje);
    }
}

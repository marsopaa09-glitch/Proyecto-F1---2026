package Logica;

public class Asignacion {

    private int numeroCompetidor;
    private Temporada temporada;
    private Piloto piloto;
    private Auto auto;

    public Asignacion(int numeroCompetidor, Temporada temporada, Piloto piloto, Auto auto) {
        this.numeroCompetidor = numeroCompetidor;
        this.temporada = temporada;
        this.piloto = piloto;
        this.auto = auto;
    }

    public void asignarPiloto(Piloto piloto) {
        this.piloto = piloto;
    }

    public void asignarAuto(Auto auto) {
        this.auto = auto;
    }

    public void asignarTemporada(Temporada temporada) {
        this.temporada = temporada;
    }

    public void cambiarNumeroCompetidor(int numero) {
        this.numeroCompetidor = numero;
    }

    public Piloto obtenerPiloto() {
        return piloto;
    }

    public Auto obtenerAuto() {
        return auto;
    }

    public Temporada obtenerTemporada() {
        return temporada;
    }

    public int getNumeroCompetidor() {
        return numeroCompetidor;
    }
}

package Logica;

public class ProveedorMotor extends Proveedor {

    private String numeroChasis;

    public ProveedorMotor(int identificador, String nombre, String numeroChasis) {
        super(identificador, nombre);
        this.numeroChasis = numeroChasis;
    }

    public void suministrarMotor(Escuderia escuderia) {
        escuderia.asignarProveedorMotor(this);
    }

    public String obtenerNumeroChasis() {
        return numeroChasis;
    }
}
    


package Logica;

import java.util.ArrayList;
import java.util.List;

public class Escuderia {
    private int identificador;
    private String nombre;
    private String pais;
    private String proveedor;
    private boolean activa;
    private int temporada;
    private List<Auto> autos;
    private ProveedorMotor proveedorMotor;

    public Escuderia(int identificador, String nombre, String pais, String proveedor, boolean activa, int temporada) {
        this.identificador = identificador;
        this.nombre = nombre;
        this.pais = pais;
        this.proveedor = proveedor;
        this.activa = activa;
        this.temporada = temporada;
        this.autos = new ArrayList<>();
    }

    public Escuderia(int identificador, String nombre) {
        this.identificador = identificador;
        this.nombre = nombre;
        this.pais = "";
        this.proveedor = "";
        this.activa = true;
        this.temporada = 2026;
        this.autos = new ArrayList<>();
    }

    public void modificarDatos(String nombre, String pais, String proveedor, boolean activa, int temporada) {
        this.nombre = nombre;
        this.pais = pais;
        this.proveedor = proveedor;
        this.activa = activa;
        this.temporada = temporada;
    }

    public void modificarIdentificador(int nuevoId) {
        this.identificador = nuevoId;
    }

    public int getIdentificador() { return identificador; }
    public String getNombre() { return nombre; }
    public String getPais() { return pais; }
    public String getProveedor() { return proveedor; }
    public boolean isActiva() { return activa; }
    public int getTemporada() { return temporada; }

    public void agregarAuto(Auto auto) { autos.add(auto); }
    public void eliminarAuto(Auto auto) { autos.remove(auto); }
    public List<Auto> obtenerAutos() { return autos; }

    public void asignarProveedorMotor(ProveedorMotor pm) { this.proveedorMotor = pm; }
    public ProveedorMotor obtenerProveedorMotor() { return proveedorMotor; }
}
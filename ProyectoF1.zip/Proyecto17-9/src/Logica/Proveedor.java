package Logica;

public class Proveedor {
    
    private int identificador;
    private String nombre;

    public Proveedor(int identificador, String nombre) {
        this.identificador = identificador;
        this.nombre = nombre;
    }

    public void modificarDatos(String nombre) {
        this.nombre = nombre;
    }

    public String obtenerInformacion() {
        return "ID: " + identificador + " - Nombre: " + nombre;
    }

    public int getIdentificador() {
        return identificador;
    }

    public String getNombre() {
        return nombre;
    }
}

package Logica;

import java.util.ArrayList;
import java.util.List;

public class Temporada {
    private int anio;
    private String fechaInicio;
    private String fechaFin;
    private boolean activa;
    private List<GranPremio> grandesPremios;
    private List<Asignacion> asignaciones;

    public Temporada(int anio, String fechaInicio, String fechaFin, boolean activa) {
        this.anio = anio;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.activa = activa;
        this.grandesPremios = new ArrayList<>();
        this.asignaciones = new ArrayList<>();
    }

    public Temporada(int anio) {
        this.anio = anio;
        this.fechaInicio = "";
        this.fechaFin = "";
        this.activa = true;
        this.grandesPremios = new ArrayList<>();
        this.asignaciones = new ArrayList<>();
    }

    public int getAnio() { return anio; }
    public String getFechaInicio() { return fechaInicio; }
    public String getFechaFin() { return fechaFin; }
    public boolean isActiva() { return activa; }

    public void agregarGranPremio(GranPremio gp) { grandesPremios.add(gp); }
    public void eliminarGranPremio(GranPremio gp) { grandesPremios.remove(gp); }
    public List<GranPremio> obtenerGrandesPremios() { return grandesPremios; }

    public void agregarAsignacion(Asignacion a) { asignaciones.add(a); }
    public void eliminarAsignacion(Asignacion a) { asignaciones.remove(a); }
    public List<Asignacion> obtenerAsignaciones() { return asignaciones; }
}
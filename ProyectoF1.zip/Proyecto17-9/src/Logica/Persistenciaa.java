package Logica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Persistenciaa {

    // 1. Verificamos que el driver JDBC de MySQL esté bien cargado
    public static boolean conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return true;
        } catch (Exception e) {
            System.out.println("No se encontró el JAR correctamente configurado");
            return false;
        }
    }

    // 2. Establecemos la conexión con la base de datos local
    public static Connection RealizarConexion() {
        Connection conexion = null;
        String url = "jdbc:mysql://localhost:3306/formula1?useSSL=false&serverTimezone=UTC";
        String usuario = "root";
        String clave = "";
        try {
            conexion = DriverManager.getConnection(url, usuario, clave);
        } catch (SQLException e) {
            System.out.println("Error de conexion: " + e.getMessage());
        }
        return conexion;
    }

    // 3. Persistencia de Piloto (Inserta, Actualiza o Elimina según la orden)
    public static void EjecutarSentencia(String datos) {
        // Si mandan una orden de eliminación
        if (datos.startsWith("ELIMINAR:")) {
            String codigo = datos.split(":")[1];
            String sqlDelete = "DELETE FROM piloto WHERE codigo_piloto = ?";
            
            try (Connection connection = Persistenciaa.RealizarConexion();
                 PreparedStatement ps = connection.prepareStatement(sqlDelete)) {
                ps.setString(1, codigo);
                ps.executeUpdate();
                System.out.println("Piloto eliminado de la BD correctamente.");
            } catch (SQLException ex) {
                System.out.println("Error al eliminar piloto en BD: " + ex.getMessage());
            }
            return;
        }

        // Si es un registro nuevo o actualización (Guardamos nombre y apellido juntos en 'nombre')
        String sql = "INSERT INTO piloto (codigo_piloto, nombre, nacionalidad, fecha_nacimiento, id_escuderia, id_proveedor_indumentaria) VALUES (?, ?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE nombre = VALUES(nombre), nacionalidad = VALUES(nacionalidad), fecha_nacimiento = VALUES(fecha_nacimiento)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setString(1, valores[0]); // Código
            
            // Unimos el nombre y el apellido en un solo texto para la columna 'nombre'
            String nombreCompleto = valores[1] + " " + valores[2];
            ps.setString(2, nombreCompleto); 
            
            ps.setString(3, valores[3]); // Nacionalidad
            
            DateTimeFormatter formatoEntrada = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate fechaParsed = LocalDate.parse(valores[4], formatoEntrada);
            ps.setDate(4, java.sql.Date.valueOf(fechaParsed)); // Fecha de nacimiento
            
            ps.setInt(5, 2); // FK Escudería por defecto
            ps.setInt(6, 3); // FK Proveedor por defecto

            ps.executeUpdate();
            System.out.println("Piloto guardado o actualizado correctamente.");

        } catch (Exception ex) {
            System.out.println("Error con la sentencia en piloto: " + ex.getMessage());
        }
    }

    // 4. Persistencia de Escudería
    public static void EjecutarSentenciaEscuderia(String datos) {
        String sql = "INSERT INTO escuderia (id_escuderia, nombre, id_proveedor, numero_chasis) VALUES (?, ?, ?, ?)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            int idGenerado = (int) (Math.random() * 100000);

            ps.setInt(1, idGenerado);
            ps.setString(2, valores[0]); // Nombre
            ps.setInt(3, Integer.parseInt(valores[1])); // ID Proveedor
            ps.setString(4, valores[2]); // Número de chasis

            ps.executeUpdate();
            System.out.println("Escudería registrada correctamente.");

        } catch (SQLException ex) {
            System.out.println("Error en escudería: " + ex.getMessage());
        }
    }

    // 5. Consulta general de pilotos para recuperar códigos y nombres
    public static String[] Consultar() {
        String datos = "";
        String sql = "SELECT * FROM piloto";

        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                datos += rs.getString("codigo_piloto") + ":" + rs.getString("nombre") + ";";
            }

        } catch (SQLException ex) {
            System.out.println("Error al consultar pilotos: " + ex.getMessage());
        }

        if (datos.isEmpty()) return new String[0];
        return datos.split(";");
    }

    // 6. Persistencia de Proveedor
    public static void EjecutarSentenciaProveedor(String datos) {
        if (datos.startsWith("ELIMINAR:")) {
            int idProveedor = Integer.parseInt(datos.split(":")[1]);
            String sqlDelete = "DELETE FROM proveedor WHERE id_proveedor = ?";
            
            try (Connection connection = Persistenciaa.RealizarConexion();
                 PreparedStatement ps = connection.prepareStatement(sqlDelete)) {
                ps.setInt(1, idProveedor);
                ps.executeUpdate();
                System.out.println("Proveedor eliminado de la BD correctamente.");
            } catch (SQLException ex) {
                System.out.println("Error al eliminar proveedor en BD: " + ex.getMessage());
            }
            return;
        }

        String sql = "INSERT INTO proveedor (id_proveedor, nombre, tipo, numero_chasis) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE nombre = VALUES(nombre), tipo = VALUES(tipo), numero_chasis = VALUES(numero_chasis)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setInt(1, Integer.parseInt(valores[0])); // ID
            ps.setString(2, valores[1]); // Nombre
            ps.setString(3, valores[2]); // Tipo
            ps.setString(4, valores[3]); // Número de chasis

            ps.executeUpdate();
            System.out.println("Proveedor registrado o actualizado correctamente en BD.");

        } catch (SQLException ex) {
            System.out.println("Error en proveedor: " + ex.getMessage());
        }
    }

    // 7. Persistencia de Temporada
    public static void EjecutarSentenciaTemporada(String datos) {
        if (datos.startsWith("ELIMINAR:")) {
            try {
                int anio = Integer.parseInt(datos.split(":")[1]);
                String sqlDelete = "DELETE FROM temporada WHERE año = ?";
                
                try (Connection connection = Persistenciaa.RealizarConexion();
                     PreparedStatement ps = connection.prepareStatement(sqlDelete)) {
                    ps.setInt(1, anio);
                    ps.executeUpdate();
                    System.out.println("Temporada eliminada de la BD correctamente.");
                }
            } catch (SQLException ex) {
                System.out.println("Error al eliminar temporada en BD: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                System.out.println("Error en formato de año para eliminar temporada: " + ex.getMessage());
            }
            return;
        }

        String sql = "INSERT INTO temporada (año, fecha_inicio, fecha_fin, estado) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE fecha_inicio = VALUES(fecha_inicio), fecha_fin = VALUES(fecha_fin), estado = VALUES(estado)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setInt(1, Integer.parseInt(valores[0])); // Año
            ps.setString(2, valores[1]); // Fecha inicio
            ps.setString(3, valores[2]); // Fecha fin
            ps.setString(4, valores[3]); // Estado

            ps.executeUpdate();
            System.out.println("Temporada registrada o actualizada correctamente en BD.");

        } catch (SQLException ex) {
            System.out.println("Error en temporada: " + ex.getMessage());
        }
    }

    // 8. Persistencia de Gran Premio
    public static void EjecutarSentenciaGranPremio(String datos) {
        if (datos.startsWith("ELIMINAR:")) {
            int idGP = Integer.parseInt(datos.split(":")[1]);
            String sqlDelete = "DELETE FROM gran_premio WHERE id_gran_premio = ?";
            
            try (Connection connection = Persistenciaa.RealizarConexion();
                 PreparedStatement ps = connection.prepareStatement(sqlDelete)) {
                ps.setInt(1, idGP);
                ps.executeUpdate();
                System.out.println("Gran Premio eliminado de la BD correctamente.");
            } catch (SQLException ex) {
                System.out.println("Error al eliminar gran premio en BD: " + ex.getMessage());
            }
            return;
        }

        String sql = "INSERT INTO gran_premio (id_gran_premio, nombre, fecha, id_circuito, temporada) VALUES (?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE nombre = VALUES(nombre), fecha = VALUES(fecha), id_circuito = VALUES(id_circuito), temporada = VALUES(temporada)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setInt(1, Integer.parseInt(valores[0])); // ID Gran Premio
            ps.setString(2, valores[1]); // Nombre
            
            DateTimeFormatter formatoEntrada = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fechaParsed = LocalDate.parse(valores[2], formatoEntrada);
            ps.setDate(3, java.sql.Date.valueOf(fechaParsed)); // Fecha
            
            ps.setString(4, valores[3]); // ID circuito
            ps.setInt(5, Integer.parseInt(valores[4])); // Temporada

            ps.executeUpdate();
            System.out.println("Gran Premio registrado o actualizado correctamente en BD.");

        } catch (SQLException ex) {
            System.out.println("Error en gran premio: " + ex.getMessage());
        }
    }

    // 9. Persistencia de Circuito
    public static void EjecutarSentenciaCircuito(String datos) {
        if (datos.startsWith("ELIMINAR:")) {
            try {
                int idCircuito = Integer.parseInt(datos.split(":")[1]);
                String sqlDelete = "DELETE FROM circuito WHERE id_circuito = ?";
                
                try (Connection connection = Persistenciaa.RealizarConexion();
                     PreparedStatement ps = connection.prepareStatement(sqlDelete)) {
                    ps.setInt(1, idCircuito);
                    ps.executeUpdate();
                    System.out.println("Circuito eliminado de la BD correctamente.");
                }
            } catch (SQLException ex) {
                System.out.println("Error al eliminar circuito en BD: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                System.out.println("Error en formato de ID para eliminar circuito: " + ex.getMessage());
            }
            return;
        }

        String sql = "INSERT INTO circuito (id_circuito, nombre, `país`, longitud_trazado, vueltas_programadas) VALUES (?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE nombre = VALUES(nombre), `país` = VALUES(`país`), longitud_trazado = VALUES(longitud_trazado), vueltas_programadas = VALUES(vueltas_programadas)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setInt(1, Integer.parseInt(valores[0])); // ID Circuito
            ps.setString(2, valores[1]); // Nombre
            ps.setString(3, valores[2]); // País
            ps.setDouble(4, Double.parseDouble(valores[3])); // Longitud
            ps.setInt(5, Integer.parseInt(valores[4])); // Vueltas

            ps.executeUpdate();
            System.out.println("Circuito registrado o actualizado correctamente en BD.");

        } catch (SQLException ex) {
            System.out.println("Error en circuito: " + ex.getMessage());
        }
    }

    // 10. Persistencia de Resultados
    public static void EjecutarSentenciaResultado(String datos) {
        String sql = "INSERT INTO resultado (id_gran_premio, codigo_piloto, id_auto, `posición`, vueltas, tiempo, puntos) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setInt(1, Integer.parseInt(valores[0])); // ID Gran Premio
            ps.setString(2, valores[1]); // Código piloto
            ps.setInt(3, Integer.parseInt(valores[2])); // ID Auto
            ps.setInt(4, Integer.parseInt(valores[3])); // Posición
            ps.setInt(5, Integer.parseInt(valores[4])); // Vueltas
            ps.setDouble(6, Double.parseDouble(valores[5])); // Tiempo
            ps.setDouble(7, Double.parseDouble(valores[6])); // Puntos

            ps.executeUpdate();
            System.out.println("Resultado registrado correctamente.");

        } catch (SQLException ex) {
            System.out.println("Error en resultado: " + ex.getMessage());
        }
    }

    // 11. Persistencia de Autos
    public static void EjecutarSentenciaAuto(String datos) {
        String sql = "INSERT INTO auto (id_auto, modelo, `año_fabricación`, id_escuderia) VALUES (?, ?, ?, ?)";
        
        try (Connection connection = Persistenciaa.RealizarConexion();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String[] valores = datos.split(":");
            ps.setInt(1, Integer.parseInt(valores[0])); // ID Auto
            ps.setString(2, valores[1]); // Modelo
            ps.setInt(3, Integer.parseInt(valores[2])); // Año de fabricación
            ps.setInt(4, Integer.parseInt(valores[3])); // ID Escudería

            ps.executeUpdate();
            System.out.println("Auto registrado correctamente.");

        } catch (SQLException ex) {
            System.out.println("Error en auto: " + ex.getMessage());
        }
    }
}
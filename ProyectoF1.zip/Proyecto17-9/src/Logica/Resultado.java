
package Logica;

public class Resultado {

    private int posicion;
    private int vueltasCompletadas;
    private double tiempoPorVuelta;
    private double puntos;
    private Piloto piloto;
    private Auto auto;
    private GranPremio granPremio;

    public Resultado(Piloto piloto, Auto auto, GranPremio granPremio, int posicion, int vueltas, double tiempo, double puntos) {
        this.piloto = piloto;
        this.auto = auto;
        this.granPremio = granPremio;
        this.posicion = posicion;
        this.vueltasCompletadas = vueltas;
        this.tiempoPorVuelta = tiempo;
        this.puntos = puntos;
    }

    public void registrarResultado(int posicion, int vueltas, double tiempo, double puntos) {
        this.posicion = posicion;
        this.vueltasCompletadas = vueltas;
        this.tiempoPorVuelta = tiempo;
        this.puntos = puntos;
    }

    public void modificarResultado(int posicion, int vueltas, double tiempo, double puntos) {
        this.posicion = posicion;
        this.vueltasCompletadas = vueltas;
        this.tiempoPorVuelta = tiempo;
        this.puntos = puntos;
    }

    public double calcularPuntos() {
        int[] tabla = {25, 18, 15, 12, 10, 8, 6, 4, 2, 1};
        if (posicion >= 1 && posicion <= tabla.length) {
            puntos = tabla[posicion - 1];
        } else {
            puntos = 0;
        }
        return puntos;
    }

    public Piloto obtenerPiloto() {
        return piloto;
    }

    public Auto obtenerAuto() {
        return auto;
    }

    public GranPremio obtenerGranPremio() {
        return granPremio;
    }

    public int getPosicion() {
        return posicion;
    }

    public double getPuntos() {
        return puntos;
    }

    public int getVueltasCompletadas() {
        return vueltasCompletadas;
    }

    public double getTiempoPorVuelta() {
        return tiempoPorVuelta;
    }
}

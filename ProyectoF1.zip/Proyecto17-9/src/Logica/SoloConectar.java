package Logica;

public class SoloConectar {

    public static boolean conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return true;
        } catch (Exception e) {
            System.out.println("Error al cargar el driver: " + e.getMessage());
            return false;
        }
    }
}
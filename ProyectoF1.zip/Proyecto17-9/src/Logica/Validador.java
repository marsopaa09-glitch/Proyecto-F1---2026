package Logica;

/**
 * Validaciones simples y reutilizables. Todas lanzan ValidacionException
 * con un mensaje claro si el dato no es válido.
 */
public class Validador {

    private Validador() {
    }

    public static void noNulo(Object valor, String campo) {
        if (valor == null) {
            throw new ValidacionException(campo + ": dato obligatorio.");
        }
    }

    public static void texto(String valor, String campo) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new ValidacionException(campo + ": no puede estar vacío.");
        }
    }

    public static void positivo(double valor, String campo) {
        if (!(valor > 0)) {
            throw new ValidacionException(campo + ": debe ser mayor que 0.");
        }
    }

    public static void noNegativo(double valor, String campo) {
        if (!(valor >= 0)) {
            throw new ValidacionException(campo + ": no puede ser negativo.");
        }
    }

    // Texto que debe contener un número entero mayor que 0 (por ejemplo, un año)
    public static void numeroEnTexto(String valor, String campo) {
        texto(valor, campo);
        int numero;
        try {
            numero = Integer.parseInt(valor.trim());
        } catch (NumberFormatException e) {
            throw new ValidacionException(campo + ": debe ser un número.");
        }
        if (numero <= 0) {
            throw new ValidacionException(campo + ": debe ser mayor que 0.");
        }
    }
}

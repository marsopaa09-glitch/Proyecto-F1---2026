package Logica;

public class Auto {
    
     private int identificador;
    private String modelo;
    private String anioFabricacion;
    private Escuderia escuderia;

    public Auto(int identificador, String modelo, String anioFabricacion) {
        this.identificador = identificador;
        this.modelo = modelo;
        this.anioFabricacion = anioFabricacion;
    }

    public void asignarEscuderia(Escuderia escuderia) {
        this.escuderia = escuderia;
    }

    public Escuderia obtenerEscuderia() {
        return escuderia;
    }

    public void modificarDatos(String modelo, String anio) {
        this.modelo = modelo;
        this.anioFabricacion = anio;
    }

    public int getIdentificador() {
        return identificador;
    }

    public String getModelo() {
        return modelo;
    }

    public String getAnioFabricacion() {
        return anioFabricacion;
    }
}
   
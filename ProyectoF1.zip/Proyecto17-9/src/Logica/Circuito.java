
package Logica;

public class Circuito {
    private int identificador;
    private String nombre;
    private String pais;
    private double longitud;
    private int vueltasProgramadas;

    public Circuito(int identificador, String nombre, String pais, double longitud, int vueltasProgramadas) {
        this.identificador = identificador;
        this.nombre = nombre;
        this.pais = pais;
        this.longitud = longitud;
        this.vueltasProgramadas = vueltasProgramadas;
    }

    public void modificarDatos(String nombre, String pais, double longitud, int vueltas) {
        this.nombre = nombre;
        this.pais = pais;
        this.longitud = longitud;
        this.vueltasProgramadas = vueltas;
    }

    public String obtenerInformacion() {
        return "Circuito: " + nombre + " - País: " + pais + " - Longitud: " + longitud + " km - Vueltas: " + vueltasProgramadas;
    }

    public int getIdentificador() {
        return identificador;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public double getLongitud() {
        return longitud;
    }

    public int getVueltasProgramadas() {
        return vueltasProgramadas;
    }
}
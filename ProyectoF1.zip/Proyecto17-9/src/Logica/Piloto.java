package Logica;

import java.time.LocalDate;

public class Piloto {
    private String codigo;
    private String nombre;
    private String apellido;
    private String nacionalidad;
    private LocalDate fechaNacimiento;

    public Piloto(String codigo, String nombre, String apellido, String nacionalidad, LocalDate fechaNacimiento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.nacionalidad = nacionalidad;
        this.fechaNacimiento = fechaNacimiento;
    }

    // Constructor por compatibilidad si se usaba de 4 parámetros
    public Piloto(String codigo, String nombre, String nacionalidad, LocalDate fechaNacimiento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = "";
        this.nacionalidad = nacionalidad;
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getNacionalidad() { return nacionalidad; }
    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
}
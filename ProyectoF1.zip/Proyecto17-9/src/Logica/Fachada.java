package Logica;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Fachada {

    private static Fachada instancia;

    private List<Temporada> temporadas;
    private List<Piloto> pilotos;
    private List<Auto> autos;
    private List<Escuderia> escuderias;
    private List<Proveedor> proveedores;
    private List<Circuito> circuitos;

    private Fachada() {
        temporadas = new ArrayList<>();
        pilotos = new ArrayList<>();
        autos = new ArrayList<>();
        escuderias = new ArrayList<>();
        proveedores = new ArrayList<>();
        circuitos = new ArrayList<>();
    }

    public static synchronized Fachada getInstancia() {
        if (instancia == null) {
            instancia = new Fachada();
        }
        return instancia;
    }

    // Temporadas
    private void validarTemporada(Temporada temporada) {
        Validador.noNulo(temporada, "Temporada");
        Validador.positivo(temporada.getAnio(), "Año");
    }

    public void agregarTemporada(Temporada temporada) {
        validarTemporada(temporada);
        if (buscarTemporada(temporada.getAnio()) != null) {
            throw new ValidacionException("Ya existe una temporada de ese año.");
        }
        temporadas.add(temporada);
    }

    public void modificarTemporada(Temporada temporada) {
        validarTemporada(temporada);
        Temporada actual = buscarTemporada(temporada.getAnio());
        if (actual == null) {
            throw new ValidacionException("No existe la temporada.");
        }
        if (actual != temporada && (!actual.obtenerGrandesPremios().isEmpty() || !actual.obtenerAsignaciones().isEmpty())) {
            throw new ValidacionException("La temporada tiene elementos asociados y no se puede reemplazar.");
        }
        temporadas.set(temporadas.indexOf(actual), temporada);
    }

    public void eliminarTemporada(int anio) {
        Temporada temporada = buscarTemporada(anio);
        if (temporada == null) {
            throw new ValidacionException("No existe la temporada.");
        }
        if (!temporada.obtenerGrandesPremios().isEmpty() || !temporada.obtenerAsignaciones().isEmpty()) {
            throw new ValidacionException("No se puede eliminar: contiene elementos asociados.");
        }
        temporadas.remove(temporada);
    }

    public List<Temporada> obtenerTemporadas() {
        return new ArrayList<>(temporadas);
    }

    public Temporada buscarTemporada(int anio) {
        for (Temporada t : temporadas) {
            if (t.getAnio() == anio) return t;
        }
        return null;
    }

    // Grandes Premios
    private void validarGranPremio(GranPremio gp, Temporada temporada) {
        Validador.noNulo(gp, "Gran Premio");
        Validador.positivo(gp.getIdentificador(), "Identificador");
        Validador.texto(gp.getNombre(), "Nombre");
        Validador.noNulo(gp.getFecha(), "Fecha");
        if (gp.getFecha().getYear() != temporada.getAnio()) {
            throw new ValidacionException("La fecha no corresponde al año de la temporada.");
        }
        Validador.noNulo(gp.getCircuito(), "Circuito");
        if (buscarCircuito(gp.getCircuito().getIdentificador()) == null) {
            throw new ValidacionException("El circuito no está registrado.");
        }
    }

    public void agregarGranPremio(GranPremio gp, Temporada temporada) {
        Validador.noNulo(temporada, "Temporada");
        if (buscarTemporada(temporada.getAnio()) != temporada) {
            throw new ValidacionException("La temporada no está registrada.");
        }
        validarGranPremio(gp, temporada);
        if (buscarGranPremio(gp.getIdentificador()) != null) {
            throw new ValidacionException("Ya existe un Gran Premio con ese ID.");
        }
        temporada.agregarGranPremio(gp);
    }

    public void modificarGranPremio(int idAnterior, GranPremio gp) {
        Validador.noNulo(gp, "Gran Premio");
        GranPremio actual = buscarGranPremio(idAnterior);
        if (actual == null) throw new ValidacionException("No existe el Gran Premio.");
        Temporada temporada = actual.obtenerTemporada();
        validarGranPremio(gp, temporada);
        List<GranPremio> lista = temporada.obtenerGrandesPremios();
        lista.set(lista.indexOf(actual), gp);
        gp.asignarTemporada(temporada);
    }

    public void modificarGranPremio(GranPremio gp) {
        modificarGranPremio(gp.getIdentificador(), gp);
    }

    public void eliminarGranPremio(GranPremio gp) {
        Validador.noNulo(gp, "Gran Premio");
        GranPremio actual = buscarGranPremio(gp.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe el Gran Premio.");
        if (!actual.obtenerResultados().isEmpty()) {
            throw new ValidacionException("No se puede eliminar: tiene resultados registrados.");
        }
        actual.obtenerTemporada().eliminarGranPremio(actual);
    }

    public List<GranPremio> obtenerGrandesPremios(Temporada temporada) {
        if (temporada == null) return new ArrayList<>();
        return new ArrayList<>(temporada.obtenerGrandesPremios());
    }

    public GranPremio buscarGranPremio(int id) {
        for (Temporada t : temporadas) {
            for (GranPremio g : t.obtenerGrandesPremios()) {
                if (g.getIdentificador() == id) return g;
            }
        }
        return null;
    }

    // Circuitos
    private void validarCircuito(Circuito c) {
        Validador.noNulo(c, "Circuito");
        Validador.positivo(c.getIdentificador(), "ID");
        Validador.texto(c.getNombre(), "Nombre");
        Validador.texto(c.getPais(), "País");
        Validador.positivo(c.getLongitud(), "Longitud");
        Validador.positivo(c.getVueltasProgramadas(), "Vueltas");
    }

    public void agregarCircuito(Circuito c) {
        validarCircuito(c);
        if (buscarCircuito(c.getIdentificador()) != null) throw new ValidacionException("Ya existe el circuito.");
        circuitos.add(c);
    }

    public void modificarCircuito(int idAnterior, Circuito c) {
        validarCircuito(c);
        Circuito actual = buscarCircuito(idAnterior);
        if (actual == null) throw new ValidacionException("No existe el circuito.");
        circuitos.set(circuitos.indexOf(actual), c);
    }

    public void modificarCircuito(Circuito c) {
        modificarCircuito(c.getIdentificador(), c);
    }

    public void eliminarCircuito(Circuito c) {
        Validador.noNulo(c, "Circuito");
        Circuito actual = buscarCircuito(c.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe el circuito.");
        for (Temporada t : temporadas) {
            for (GranPremio gp : t.obtenerGrandesPremios()) {
                if (gp.getCircuito() != null && gp.getCircuito().getIdentificador() == actual.getIdentificador()) {
                    throw new ValidacionException("No se puede eliminar: lo usa un Gran Premio.");
                }
            }
        }
        circuitos.remove(actual);
    }

    public List<Circuito> obtenerCircuitos() {
        return new ArrayList<>(circuitos);
    }

    public Circuito buscarCircuito(int id) {
        for (Circuito c : circuitos) {
            if (c.getIdentificador() == id) return c;
        }
        return null;
    }

    // Pilotos
    private void validarPiloto(Piloto p) {
        Validador.noNulo(p, "Piloto");
        Validador.texto(p.getCodigo(), "Código");
        Validador.texto(p.getNombre(), "Nombre");
        Validador.texto(p.getNacionalidad(), "Nacionalidad");
        Validador.noNulo(p.getFechaNacimiento(), "Fecha de nacimiento");
        if (p.getFechaNacimiento().isAfter(LocalDate.now())) {
            throw new ValidacionException("La fecha de nacimiento no puede ser futura.");
        }
    }

    public void agregarPiloto(Piloto p) {
        validarPiloto(p);
        if (buscarPiloto(p.getCodigo()) != null) throw new ValidacionException("Ya existe un piloto con ese código.");
        pilotos.add(p);
    }

    public boolean modificarPiloto(String codigoOriginal, Piloto p) {
        validarPiloto(p);
        Piloto actual = buscarPiloto(codigoOriginal);
        if (actual == null) throw new ValidacionException("No existe el piloto.");
        pilotos.set(pilotos.indexOf(actual), p);
        return true;
    }

    public void modificarPiloto(Piloto p) {
        modificarPiloto(p.getCodigo(), p);
    }

    public void eliminarPiloto(Piloto p) {
        Validador.noNulo(p, "Piloto");
        Piloto actual = buscarPiloto(p.getCodigo());
        if (actual == null) throw new ValidacionException("No existe el piloto.");
        for (Temporada t : temporadas) {
            for (Asignacion a : t.obtenerAsignaciones()) {
                if (a.obtenerPiloto() != null && a.obtenerPiloto().getCodigo().equalsIgnoreCase(actual.getCodigo())) {
                    throw new ValidacionException("No se puede eliminar: tiene auto asignado.");
                }
            }
        }
        if (!consultarResultados(actual).isEmpty()) {
            throw new ValidacionException("No se puede eliminar: tiene resultados.");
        }
        pilotos.remove(actual);
    }

    public List<Piloto> obtenerPilotos() {
        return new ArrayList<>(pilotos);
    }

    public Piloto buscarPiloto(String codigo) {
        for (Piloto p : pilotos) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        }
        return null;
    }

    // Autos
    private void validarAuto(Auto a) {
        Validador.noNulo(a, "Auto");
        Validador.positivo(a.getIdentificador(), "ID");
        Validador.texto(a.getModelo(), "Modelo");
        Validador.numeroEnTexto(a.getAnioFabricacion(), "Año");
    }

    public void agregarAuto(Auto a) {
        validarAuto(a);
        if (buscarAuto(a.getIdentificador()) != null) throw new ValidacionException("Ya existe el auto.");
        autos.add(a);
    }

    public void modificarAuto(Auto a) {
        validarAuto(a);
        Auto actual = buscarAuto(a.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe el auto.");
        Escuderia esc = actual.obtenerEscuderia();
        if (actual != a && a.obtenerEscuderia() == null && esc != null) {
            int pos = esc.obtenerAutos().indexOf(actual);
            a.asignarEscuderia(esc);
            if (pos >= 0) esc.obtenerAutos().set(pos, a);
        }
        autos.set(autos.indexOf(actual), a);
    }

    public void eliminarAuto(Auto a) {
        Validador.noNulo(a, "Auto");
        Auto actual = buscarAuto(a.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe el auto.");
        for (Temporada t : temporadas) {
            for (Asignacion asig : t.obtenerAsignaciones()) {
                if (asig.obtenerAuto() != null && asig.obtenerAuto().getIdentificador() == actual.getIdentificador()) {
                    throw new ValidacionException("No se puede eliminar: está asignado.");
                }
            }
            for (GranPremio gp : t.obtenerGrandesPremios()) {
                for (Resultado r : gp.obtenerResultados()) {
                    if (r.obtenerAuto() != null && r.obtenerAuto().getIdentificador() == actual.getIdentificador()) {
                        throw new ValidacionException("No se puede eliminar: tiene resultados.");
                    }
                }
            }
        }
        if (actual.obtenerEscuderia() != null) actual.obtenerEscuderia().eliminarAuto(actual);
        autos.remove(actual);
    }

    public List<Auto> obtenerAutos() {
        return new ArrayList<>(autos);
    }

    public Auto buscarAuto(int id) {
        for (Auto a : autos) {
            if (a.getIdentificador() == id) return a;
        }
        return null;
    }

    // Escuderías
    private void validarEscuderia(Escuderia e) {
        Validador.noNulo(e, "Escudería");
        Validador.positivo(e.getIdentificador(), "ID");
        Validador.texto(e.getNombre(), "Nombre");
        for (Escuderia otra : escuderias) {
            if (otra.getIdentificador() != e.getIdentificador() && otra.getNombre().trim().equalsIgnoreCase(e.getNombre().trim())) {
                throw new ValidacionException("Ya existe una escudería con ese nombre.");
            }
        }
    }

    public void agregarEscuderia(Escuderia e) {
        validarEscuderia(e);
        if (buscarEscuderia(e.getIdentificador()) != null) throw new ValidacionException("Ya existe la escudería.");
        escuderias.add(e);
    }

    public void modificarEscuderia(Escuderia e) {
        validarEscuderia(e);
        Escuderia actual = buscarEscuderia(e.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe la escudería.");
        if (actual != e) {
            for (Auto a : new ArrayList<>(actual.obtenerAutos())) e.agregarAuto(a);
            if (e.obtenerProveedorMotor() == null && actual.obtenerProveedorMotor() != null) {
                e.asignarProveedorMotor(actual.obtenerProveedorMotor());
            }
        }
        escuderias.set(escuderias.indexOf(actual), e);
    }

    public void eliminarEscuderia(Escuderia e) {
        Validador.noNulo(e, "Escudería");
        Escuderia actual = buscarEscuderia(e.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe la escudería.");
        if (!actual.obtenerAutos().isEmpty()) throw new ValidacionException("No se puede eliminar: tiene autos.");
        escuderias.remove(actual);
    }

    public List<Escuderia> obtenerEscuderias() {
        return new ArrayList<>(escuderias);
    }

    public Escuderia buscarEscuderia(int id) {
        for (Escuderia e : escuderias) {
            if (e.getIdentificador() == id) return e;
        }
        return null;
    }

    // Proveedores
    private void validarProveedor(Proveedor p) {
        Validador.noNulo(p, "Proveedor");
        Validador.positivo(p.getIdentificador(), "ID");
        Validador.texto(p.getNombre(), "Nombre");
        if (p instanceof ProveedorMotor) {
            Validador.texto(((ProveedorMotor) p).obtenerNumeroChasis(), "Chasis");
        }
    }

    public void agregarProveedor(Proveedor p) {
        validarProveedor(p);
        if (buscarProveedor(p.getIdentificador()) != null) throw new ValidacionException("Ya existe el proveedor.");
        proveedores.add(p);
    }

    public void modificarProveedor(int idAnterior, Proveedor p) {
        validarProveedor(p);
        Proveedor actual = buscarProveedor(idAnterior);
        if (actual == null) throw new ValidacionException("No existe el proveedor.");
        proveedores.set(proveedores.indexOf(actual), p);
    }

    public void modificarProveedor(Proveedor p) {
        modificarProveedor(p.getIdentificador(), p);
    }

    public void eliminarProveedor(Proveedor p) {
        Validador.noNulo(p, "Proveedor");
        Proveedor actual = buscarProveedor(p.getIdentificador());
        if (actual == null) throw new ValidacionException("No existe el proveedor.");
        for (Escuderia e : escuderias) {
            if (e.obtenerProveedorMotor() != null && e.obtenerProveedorMotor().getIdentificador() == actual.getIdentificador()) {
                throw new ValidacionException("No se puede eliminar: provee motor a una escudería.");
            }
        }
        proveedores.remove(actual);
    }

    public List<ProveedorMotor> obtenerProveedoresMotor() {
        List<ProveedorMotor> motores = new ArrayList<>();
        for (Proveedor p : proveedores) {
            if (p instanceof ProveedorMotor) motores.add((ProveedorMotor) p);
        }
        return motores;
    }

    // Asignaciones y Resultados
    public void asignarPilotoAuto(Asignacion a) {
        Validador.noNulo(a, "Asignación");
        Temporada t = a.obtenerTemporada();
        Validador.noNulo(t, "Temporada");
        if (buscarTemporada(t.getAnio()) != t) throw new ValidacionException("Temporada no registrada.");
        Piloto p = a.obtenerPiloto();
        Validador.noNulo(p, "Piloto");
        if (buscarPiloto(p.getCodigo()) == null) throw new ValidacionException("Piloto no registrado.");
        Auto auto = a.obtenerAuto();
        Validador.noNulo(auto, "Auto");
        if (buscarAuto(auto.getIdentificador()) == null) throw new ValidacionException("Auto no registrado.");
        if (auto.obtenerEscuderia() == null) throw new ValidacionException("El auto no pertenece a ninguna escudería.");
        Validador.positivo(a.getNumeroCompetidor(), "Número");

        for (Asignacion otra : t.obtenerAsignaciones()) {
            if (otra.obtenerPiloto().getCodigo().equalsIgnoreCase(p.getCodigo())) {
                throw new ValidacionException("El piloto ya tiene auto asignado.");
            }
            if (otra.obtenerAuto().getIdentificador() == auto.getIdentificador()) {
                throw new ValidacionException("El auto ya está asignado.");
            }
            if (otra.getNumeroCompetidor() == a.getNumeroCompetidor()) {
                throw new ValidacionException("El número de competidor está en uso.");
            }
        }
        t.agregarAsignacion(a);
    }

    public void eliminarAsignacion(Asignacion a) {
        Validador.noNulo(a, "Asignación");
        Temporada t = a.obtenerTemporada();
        Validador.noNulo(t, "Temporada");
        if (!t.obtenerAsignaciones().contains(a)) throw new ValidacionException("La asignación no existe.");
        for (GranPremio gp : t.obtenerGrandesPremios()) {
            for (Resultado r : gp.obtenerResultados()) {
                if (r.obtenerPiloto().getCodigo().equalsIgnoreCase(a.obtenerPiloto().getCodigo())
                        && r.obtenerAuto().getIdentificador() == a.obtenerAuto().getIdentificador()) {
                    throw new ValidacionException("No se puede eliminar: tiene resultados asociados.");
                }
            }
        }
        t.eliminarAsignacion(a);
    }

    public void registrarResultado(Resultado res) {
        Validador.noNulo(res, "Resultado");
        GranPremio gp = res.obtenerGranPremio();
        Validador.noNulo(gp, "Gran Premio");
        if (buscarGranPremio(gp.getIdentificador()) != gp) throw new ValidacionException("Gran Premio no registrado.");
        
        Temporada temporada = gp.obtenerTemporada();
        if (temporada == null) throw new ValidacionException("El Gran Premio no tiene temporada asociada.");

        Piloto p = res.obtenerPiloto();
        Auto auto = res.obtenerAuto();
        Validador.noNulo(p, "Piloto");
        Validador.noNulo(auto, "Auto");

        boolean asignado = false;
        for (Asignacion asig : temporada.obtenerAsignaciones()) {
            if (asig.obtenerPiloto().getCodigo().equalsIgnoreCase(p.getCodigo())
                    && asig.obtenerAuto().getIdentificador() == auto.getIdentificador()) {
                asignado = true;
            }
        }
        if (!asignado) throw new ValidacionException("El piloto no tiene asignado ese auto.");

        Validador.positivo(res.getPosicion(), "Posición");
        int participantes = temporada.obtenerAsignaciones().size();
        if (res.getPosicion() > participantes) throw new ValidacionException("Posición mayor que los inscriptos.");
        Validador.noNegativo(res.getVueltasCompletadas(), "Vueltas");
        if (gp.getCircuito() != null && res.getVueltasCompletadas() > gp.getCircuito().getVueltasProgramadas()) {
            throw new ValidacionException("Vueltas superan las del circuito.");
        }
        Validador.noNegativo(res.getTiempoPorVuelta(), "Tiempo");

        for (Resultado otro : gp.obtenerResultados()) {
            if (otro.obtenerPiloto().getCodigo().equalsIgnoreCase(p.getCodigo())) {
                throw new ValidacionException("El piloto ya tiene resultado.");
            }
            if (otro.getPosicion() == res.getPosicion()) {
                throw new ValidacionException("La posición ya está ocupada.");
            }
        }
        res.calcularPuntos();
        gp.registrarResultado(res);
    }

    public List<Resultado> consultarResultados(GranPremio gp) {
        return gp.obtenerResultados();
    }

    public List<Resultado> obtenerResultadosTemporada(Temporada t) {
        List<Resultado> lista = new ArrayList<>();
        if (t != null) {
            for (GranPremio gp : t.obtenerGrandesPremios()) lista.addAll(gp.obtenerResultados());
        }
        return lista;
    }

    public List<Piloto> obtenerClasificacionPilotos() {
        List<Piloto> clasif = new ArrayList<>(pilotos);
        clasif.sort((a, b) -> Double.compare(puntosDePiloto(b), puntosDePiloto(a)));
        return clasif;
    }

    public List<Resultado> obtenerRankingGrandesPremios() {
        List<Resultado> ranking = todosLosResultados();
        ranking.sort((a, b) -> Double.compare(b.getPuntos(), a.getPuntos()));
        return ranking;
    }

    public List<Escuderia> obtenerEscuderiasPorPremios() {
        List<Escuderia> ranking = new ArrayList<>(escuderias);
        ranking.sort((a, b) -> Double.compare(puntosDeEscuderia(b), puntosDeEscuderia(a)));
        return ranking;
    }

    private List<Resultado> todosLosResultados() {
        List<Resultado> todos = new ArrayList<>();
        for (Temporada t : temporadas) {
            for (GranPremio gp : t.obtenerGrandesPremios()) todos.addAll(gp.obtenerResultados());
        }
        return todos;
    }

    private double puntosDePiloto(Piloto p) {
        double total = 0;
        for (Resultado r : todosLosResultados()) {
            Piloto pilotoRes = r.obtenerPiloto();
            if (pilotoRes != null && pilotoRes.getCodigo().equals(p.getCodigo())) total += r.getPuntos();
        }
        return total;
    }

    private double puntosDeEscuderia(Escuderia e) {
        double total = 0;
        for (Resultado r : todosLosResultados()) {
            Auto a = r.obtenerAuto();
            if (a != null && a.obtenerEscuderia() != null && a.obtenerEscuderia().getIdentificador() == e.getIdentificador()) {
                total += r.getPuntos();
            }
        }
        return total;
    }

    public List<Proveedor> obtenerProveedores() {
        return new ArrayList<>(proveedores);
    }

    public Proveedor buscarProveedor(int id) {
        for (Proveedor p : proveedores) {
            if (p.getIdentificador() == id) return p;
        }
        return null;
    }

    public List<Asignacion> obtenerAsignaciones(Temporada t) {
        if (t == null) return new ArrayList<>();
        return new ArrayList<>(t.obtenerAsignaciones());
    }

    public List<Auto> obtenerAutos(Escuderia e) {
        if (e == null) return new ArrayList<>();
        return new ArrayList<>(e.obtenerAutos());
    }

    public List<Escuderia> obtenerEscuderias(Temporada t) {
        List<Escuderia> partes = new ArrayList<>();
        if (t != null) {
            for (Asignacion a : t.obtenerAsignaciones()) {
                Auto auto = a.obtenerAuto();
                if (auto != null && auto.obtenerEscuderia() != null && !partes.contains(auto.obtenerEscuderia())) {
                    partes.add(auto.obtenerEscuderia());
                }
            }
        }
        return partes;
    }

    public List<Resultado> consultarResultados(Temporada t) {
        return obtenerResultadosTemporada(t);
    }

    public List<Resultado> consultarResultados(Piloto p) {
        List<Resultado> lista = new ArrayList<>();
        if (p == null) return lista;
        for (Resultado r : todosLosResultados()) {
            Piloto pilotoRes = r.obtenerPiloto();
            if (pilotoRes != null && pilotoRes.getCodigo().equals(p.getCodigo())) lista.add(r);
        }
        return lista;
    }
}
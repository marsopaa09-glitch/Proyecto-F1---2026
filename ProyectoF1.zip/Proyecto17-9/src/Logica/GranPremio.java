package Logica;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class GranPremio {

    private int identificador;
    private String nombre;
    private LocalDate fecha;
    private Circuito circuito;
    private Temporada temporada;
    private List<Resultado> resultados;

    public GranPremio(int identificador, String nombre, LocalDate fecha) {
        this.identificador = identificador;
        this.nombre = nombre;
        this.fecha = fecha;
        this.resultados = new ArrayList<>();
    }

    public void asignarTemporada(Temporada temporada) {
        this.temporada = temporada;
    }

    public Temporada obtenerTemporada() {
        return temporada;
    }

    public void asignarCircuito(Circuito circuito) {
        this.circuito = circuito;
    }

    public void registrarResultado(Resultado resultado) {
        if (resultado != null && !resultados.contains(resultado)) {
            resultados.add(resultado);
        }
    }

    public void eliminarResultado(Resultado resultado) {
        resultados.remove(resultado);
    }

    public List<Resultado> obtenerResultados() {
        return resultados;
    }

    public int getIdentificador() {
        return identificador;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public Circuito getCircuito() {
        return circuito;
    }
}
